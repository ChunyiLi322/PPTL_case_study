#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: langtools.py - methods and classes for processing natural language

import copy
from groups import *
from parser import *
from . import *

class PredicateExtractor:
    """Takes typed dependencies and extracts predicates out of them."""
    def extract_predicates( self, deps ):
        preds = []
        for i in deps:
            if i.in_relns( "subj" ):
                preds.append( i.gov )
        return preds

class FlexibleExtractor:
    """Takes typed dependencies and extracts dependency of particular relation."""
    base_reln = None # to be specified in descendants

    def extract( self, deps, with_conjs = False, head_word = None ):
        subjs = []

        # for all dependencies, look for the relationship, and the word at which
        # it should be based (@head_word)
        for i in deps:
            if i.in_relns( self.base_reln ) and ( head_word is None or i.gov == head_word ):
                subjs.append( i.dep )
        
        # handle multiple occurences joined by conjunctions
        # if there are conj dependencies heading from the extracted word, they are most
        # likely cases of multiple occurence so add them to result
        multi = subjs
        for i in deps:        
            if i.gov in multi and i.in_relns( "conj" ):
                if with_conjs:
                    if i.reln_specific in "and":
                       multi.append( "&&" )
                    elif i.reln_specific in "or":
                       multi.append( "||" )
                    else:
                       multi.append(i.reln_specific)
                 #modefied by CYS in 2013.9.5      
                multi.append( i.dep )

        return subjs

    def extract_nn( self, base, deps ):
        """Extracts noun compound modifiers of the @base word. 
        Sometimes the subject's name is hidden there."""
        res = []
        for dep in deps:
            if dep.gov == base and dep.in_relns( "nn" ):
                res.append( dep.dep.value )
        
        # join all found nns together
        if len( res ) > 0:
            resw = Word( " ".join( res ), base.index, base.type )
            return resw
        else:
            return None


    
    def extract_str( self, deps, head_word = None ):
        """Find the particular dependencies and eventually multiple occurences heading from
        them, and join them all toghether and ouput string as a result."""
        ss = self.extract( deps, True, head_word )
        res = []

        # for each extracted word, try to find its noun compound modifiers and
        # eventually add/replace them to/in the result
        # this is done because if sentence is: "the signal A" the output would
        # be signal, not A
        for x in ss:
            if type( x ) in [ unicode, str ]:
                res.append(x)
            else:
                # look if this is not just a generic name for signal (real names would be in nn deps)
                nn = None
                # if it is a signal, output just its name
                if GroupDirectory().in_group( WordStemmer().stem( x ).value, "signal" ):
                    nn = self.extract_nn( x, deps )

                if nn is not None:
                    res.append(nn.value)
                else:
                    res.append(x.value)
            
            #res += " "
        return res

class SubjectExtractor( FlexibleExtractor ):
    """Takes typed dependencies and extracts predicates out of them."""
    base_reln = "subj"

    def extract_subjects( self, deps, with_conjs = False ):
        return self.extract( deps, with_conjs )

class ObjectExtractor( FlexibleExtractor ):
    """Takes typed dependencies and extracts predicates out of them."""
    base_reln = "obj"

    def extract_subjects( self, deps, with_conjs = False ):
        return self.extract( deps, with_conjs )

class DisjunctStructure:
    """Holds dependencies and words for disjunct structures (independent temporal units)"""
    deps = None
    words = None
    conj_prev = None
    conj_next = None

    def __init__( self ):
        self.deps = []
        self.words = []

    def append( self, x ):
        self.deps.append( x )

    def __iter__( self ):
        return self.deps.__iter__()

class Disjuncter:
    """Takes typed dependencies and list of predicates, and extracts individual disjunct structures.
    Disjunct structure is a structure with at least main phrase and zero to N 
    other phrases. Disjunct structures are interconnected by conjuctions (the conj
    link in typed dependencies."""
    def disjunct( self, deps ):
        # copy deps so that we can safely operate with them
        deps = copy.copy( deps )

        # init list of DS conj dependencies
        conj_deps = []
        conj_s = {}

        # prepare result
        ds_count = 0
        ds = []

        # helper list of processed deps
        procsd = []
        
        # get predicates (to tell multiple subjects conjunctions from sentence conjs.)
        pe = PredicateExtractor()
        preds = pe.extract_predicates( deps )#list contain predicate
        #print preds   #delete

        # create incidence matrix of the dependencies
        inc_m = {} #dictionary
        for dep in deps:
            # if it is a sentence conjunction (one/both of its ends are predicates), mark it for deletion
            if dep.in_relns( 'conj' ) and (dep.gov in preds or dep.dep in preds):
                conj_deps.append( dep )
                continue

            act = inc_m.get( dep.gov, {} )   #
            act[ dep.dep ] = dep
            inc_m[ dep.gov ] = act
            
            act = inc_m.get( dep.dep, {} )   #
            act[ dep.gov ] = dep
            inc_m[ dep.dep ] = act
        
        # remove conj deps from deplist (only if they join sentences.. because they can join multiple subjects as well)
        for dep in conj_deps:
            deps.remove( dep )
        
        # while there are some dependencies left, create a new disjunct structure
        # and add all linked deps to the disjunct structure; end when there are no
        # dependencies left
        act_ds = None
        while len( deps ) > 0:
            # create new disjunct structure
            act_ds = DisjunctStructure()
            ds.append( act_ds )# ds contain act_ds
            
            # go from the word of first dependency
            search = [ deps[ 0 ].gov ]
            searched = []

            # while there are still some words left to search
            while len( search ) > 0:
                # pop it
                act_w = search.pop()
                # mark it as searched
                searched.append( act_w )
                # go through all dependencies where the word figures
                for k, val in inc_m[ act_w ].items():
                    # if this dependency isn't already processed, 
                    if not val in act_ds:
                        # add it to this disjunct structure deplist
                        act_ds.append( val )
                        # remove from deps to process
                        deps.remove( val )

                    # if the gov hasn't been searched, add it to words to search
                    if not ( val.gov in searched ):
                        search.append( val.gov )
                    # if the dep hasn't been searched, add it to words to search
                    if not ( val.dep in searched ):
                        search.append( val.dep )
            
            # find conjunctions .modified by CYS in 2013.9.25(line:12)
            for d in act_ds.deps:
                for c in conj_deps:
                    if d.gov in [ c.gov, c.dep ]:
                        conj_deplist=conj_s.get( act_ds, [] )
                        if c not in conj_deplist:
                            conj_deplist.append(c)
                        conj_s[ act_ds ] = conj_deplist
                    elif d.dep in [ c.gov, c.dep ]:
                        conj_deplist=conj_s.get( act_ds, [] )
                        if c not in conj_deplist:
                            conj_deplist.append(c)
                        conj_s[ act_ds ] = conj_deplist



        
        return ds, conj_s


class Phrase:
    """Holds information about a phrase (predicate, dependencies, tags)."""

    # predicate
    pred = None

    # dependencies
    deps = None

    # extracted tags
    tags = None

    def __init__( self, pred, deps, tags ):
        self.pred = pred
        self.deps = deps
        self.tags = tags
    
    def set_tags( self, tags ):
        """Add tags."""
        self.tags.extend( tags )

    def get_subj( self ):
        """Get the subject of this phrase."""
        se = SubjectExtractor()
        subj = se.extract_subjects( self.deps )
        return subj

    def get_subj_str( self ):
        """Get the subject of this phrase as a string."""
        se = SubjectExtractor()
        return se.extract_str( self.deps )

    def in_subjs( self, subj ):
        """Check for presence of @subj in subjects of this phrase."""
        se = SubjectExtractor()
        return subj in [ s.value for s in se.extract_subjects( self.deps ) ]
    
    def get_pred( self ):
        """Get the predicate of this sentence."""
        pe = PredicateExtractor()
        pred = pe.extract_predicates( self.deps )[ 0 ]
        return pred
    
    #for move to or go to or locate ,get object.(include multi object)
    # modified by CYS in 2013.9.22.(line:269-295)
    def get_special_object(self):
        objects = []
        res = ""
        for i in self.deps:
            if (i.in_relns("prep")or i.in_relns("xcomp")) and self.pred ==i.gov:
                objects.append(i.dep)
                
        multi = objects
        for i in self.deps:
            if i.gov in multi and i.in_relns("conj"):
                if i.reln_specific in "and":
                    multi.append("&&")
                elif i.reln_specific in "or":
                    multi.append("||")
                else:
                    multi.append(i.reln_specific)
                    
                multi.append(i.dep)
                
        for i in multi:
            if type(i) in [unicode,str]:
                res+=i
            else:
                res+=i.value
        
        res+=""
        return "%s" % res.strip()


class SentenceSeparator:
    """Separates sentences into phrases."""
    def __init__( self ):
        self.pe = PredicateExtractor()

    def separate( self, deps ):
        """Separate sentence represented by @deps into a set of phrases."""
        # copy deps to opearte with it safely
        deps = copy.copy( deps )
        processed_deps = 0
        preds = self.pe.extract_predicates( deps )# preds is a list which contain predicates.
        
        phrases = {}#dictionary

        # go from each predicate as far as possible but not to some other predicate
        # and add words on the way
        for pred in preds:
            custompreds = copy.copy( preds )
            custompreds.remove( pred )
            actdeps = []
            search = [ pred ]
            searched = []
            while len( search ) > 0:
                act_w = search.pop()
                searched.append( act_w )
                for dep in deps:
                    if dep.gov in custompreds or dep.dep in custompreds:# do not contain other act .
                        continue
                    if dep.gov == act_w:
                        if not dep.dep in searched:search.append( dep.dep )
                        if not dep in actdeps: actdeps.append( dep )
                    elif dep.dep == act_w:
                        if not dep.gov in searched: search.append( dep.gov )
                        if not dep in actdeps: actdeps.append( dep )


            phrases[ pred ] = actdeps
            processed_deps += len( actdeps )
        
        # create Phrase instances out of the extracted dependencies
        res = []
        for k, v in phrases.items():
            np = Phrase( k, v, [] )#the object of Phrase
            res.append( np )

        return res#the list of the object of Phrase

