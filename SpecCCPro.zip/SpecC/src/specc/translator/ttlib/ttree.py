import sys
#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: ttree.py - temporal tree implementation


import synth
from understanding import *
from patterns import *
from groups import *
from langtools import *

class TTNode:
    """Node of a temporal tree."""

    # children of this node
    children = None

    # the node's parent
    parent = None

    # tags of this node
    tags = None

    def __init__( self, kwargs = {} ):
        self.children = []
        self.tags = []
        self.kwargs = kwargs
    

    def add_child( self, *chldrn, **kwargs ):
        for ch in chldrn:
            if not ch in self.children:
                self.children.append( ch )
                if kwargs.get( 'setparent', True ) is True:
                    ch.parent = self

    def add_tag( self, *tags ):
        for tag in tags:
            if not isinstance( tag, Tag ):
                raise Exception( "tag argument must be Tag's child" )
            if not tag in self.tags:
                self.tags.append( tag )


    def has_tag( self, *tags ):
        for tag in tags:
            there = False
            for tag2 in self.tags:
                if tag.name == tag2.name:
                    there = True
                    break

            if not there:
                return False
        return True

    def get_tag( self, name ):
        for tag in self.tags:
            if tag.name == name:
                return tag
    
    def toggle_tag( self, tag ):
        if not self.has_tag( tag ):
            self.tags.append( tag )
        else:
            self.tags.remove( self.get_tag( tag.name ) )

    def get_text( self,collectlist ):
        """Convert the node to temporal formula."""
        return "%s(%s)" % ( self.oper_str(), self.children[ 0 ].get_text(collectlist), )
    
    def get_sibling( self ):
        """Get the node's sibling if exists."""
        if self.parent is None:
            return None
        for ch in self.parent.children:
            if ch is not self:
                return ch
    
    def get_agent( self ):
        """Get agent of this node that represents @self.phrase as string."""
        return self.phrase.get_subj_str()
    
    def get_operators( self, prefix = "" ):
        """Infer temporal operators from tags of this node."""
        oper = []
        # figure out operators
        # if the sibling was in past (e.g. after..), this must be future
        sibling = self.get_sibling()
        #modified by CYS in 2013.9.6(line:94-132)
        reln_specific_list = []
        # get reln_specific list from phrase
        if isinstance(self,TTTermNode):
           for i in self.phrase.deps :
              reln_specific_list.append(i.reln_specific)
        # were there cycles mentioned?
        
        if self.has_tag( Tag( prefix + "cycle" ) ) :    
            howmany_cycles = self.get_tag( prefix + "cycle" ).args[0].value
            try:
                howmany_cycles = int( howmany_cycles )
            except:
                howmany_cycles = text2int( howmany_cycles )
            if  "within" in reln_specific_list:   
               while howmany_cycles > 0:
                     oper.append("X"*howmany_cycles)
                     howmany_cycles=howmany_cycles-1
                     
            else:
                oper += "X"*howmany_cycles
                  
        
        else:
            if self.has_tag( Tag( prefix + "future" ) ):    oper += "<>"
            elif sibling is not None:
                if sibling.has_tag( Tag( prefix + "past" ) ):
                    if sibling.has_tag( Tag( prefix + "im" ) ):
                        oper += "X"
                    else:
                        oper += "<>"  # added by cys in 2013.9.4
        
        # globally?
        if self.has_tag( Tag( prefix + "globally" ) ):  oper += "[]" # added by cys in 2013.9.4
        #move to or go to
        if self.has_tag( Tag( prefix + "next" ) ):       oper +="X"
        # was this negated?
        if self.has_tag( Tag( prefix + "not" ) ):       oper += "!"

        return oper

    def get_temporal_operators_recursive( self ):
        """Recursively obtain all temporal operators that are present in the node
        or its descendants."""
        res = []
        tocheck = self.children + [ self ]
        checked = []
        while len( tocheck ) > 0:
            node = tocheck.pop()
            if node in checked:
                continue
            checked += [ node ]
            tocheck += node.children
            #if isinstance( node, TTUntilNode ):
            res +=node.tags 
            #res += [ x for x in node.get_operators() if x in [ '<>', '[]', 'X' ] ]
            # added by cys in 2013.9.4
        return res

    def oper_str( self, prefix = "" ):
        """Return operators of this node as string."""
        return "".join( self.get_operators( prefix ) )

class TTProxyNode( TTNode ):
    """Functions just like a proxy node that can posess additional tags (-> temp. operators)."""
    def __init__( self, thenode ):
        TTNode.__init__( self )
        self.proxy_for = thenode

    def get_text( self ,collectlist):
        return "%s%s" % ( self.oper_str(), self.proxy_for.get_text(collectlist), )


# If the signal C is set, after setting the signal A, eventually the signal B is set.
class TTTermNode( TTNode ):
    """Represents a final phrase."""
    def __init__( self, phrase ):
        TTNode.__init__( self )
        self.phrase = phrase
        self.tags = self.phrase.tags
        self.process()


    def process( self ):
        """Processes the phrase, and identifies eventually the prepositional
        clause. Ultimately, it adds children (subtree) to this node -- main 
        clause, prep. clauses, ..."""
        resnode = mainc = TTMainClauseNode( self.phrase )
        #print "ok1"
        mainc.suck_tags( self )
        # edge handling
        if self.has_tag( Tag( "edge" ) ):
            # (!(clk and X!clk)) U ( (clk and X!clk) and X ack ))
            # !clkevent U ( clkevent and X(signal))
            resnode = TTUntilNode()
            edge_neg = TTEdgeNode( self.get_tag( "edge" ) )
            #print "ok2"
            edge_neg.add_tag( Tag( 'not' ) )

            edge = TTEdgeNode( self.get_tag( "edge" ) )
            mainc.add_tag( Tag( 'cycle', [ Word( '1' ) ] ) )

            andnode = TTAndNode()
            andnode.add_child( edge, mainc )
            resnode.add_child( edge_neg, andnode )

        # prepositional clause handling
        if self.has_tag( Tag( "prepc" ) ) or self.has_tag( Tag( "purpose_clause" ) ):
            objc = TTObjClauseNode( self.phrase.deps )
            objc.suck_tags( self )
            prep = None
            #print "ok3"
            for dep in self.phrase.deps:
                if dep.in_relns( "prepc" ):
                    prep = dep.reln_specific
                    objc.dep = dep.dep
                    break
                elif dep.in_relns( "aux" ) and dep.dep == Word( "to" ):
                    prep = "to"
                    objc.dep = dep.gov



            resnode = None
            mainc.tags += self.tags
            self.tags = []
            if prep == "after":
                objc.tags.append( Tag( 'past' ) )
                objc.tags.append( Tag( 'if' ) )
                resnode = TTImplNode()
                resnode.tags.append( Tag( 'future' ) )
                resnode.add_child( objc )
                resnode.add_child( mainc )
            # purpose clause
            elif prep == "to":
                mainc.tags.append( Tag( 'if' ) )
                resnode = TTImplNode()
                resnode.add_child( mainc )
                resnode.add_child( objc )
        
        self.resnode = resnode
        #print "ok4"
        self.add_child( resnode )

    def get_text( self ,collectlist):
        #modefied by CYS in 2013.9.6
        reln_specific_list = []
        res = ""
        # get reln_specific list from phrase
        for i in self.phrase.deps :
            reln_specific_list.append(i.reln_specific)
        #the process of within of the cycle .
        if "within" in reln_specific_list and self.has_tag( Tag( "" + "cycle" ) ) :
            for operator in self.get_operators():
                res = res+operator+self.resnode.get_text(collectlist)+"||"
            
            res = res +self.resnode.get_text(collectlist)
            
            return "(%s)" % ( res, )
        else:
            return "%s(%s)" % ( self.oper_str(), self.resnode.get_text(collectlist), )
    
        


class TTEdgeNode( TTNode ):
    """Represents an edge node - node that expresses change in signal."""
    def __init__( self, tag ):
        TTNode.__init__( self )
        self.tag = tag

    def get_text( self,collectlist ):
        if self.tag.args[0].value == "positive":
            txt = "!%s and X%s"
        else:
            txt = "%s and X!%s"

        res = txt % ( self.tag.args[1].value, self.tag.args[1].value, )

        return "%s(%s)" % ( self.oper_str(), res, )

class TTObjClauseNode( TTNode ):
    """Represents a clause where object is the agent (i.e. purpose clause, 
    prepositional clause."""
    def __init__( self, deps ):
        TTNode.__init__( self )
        self.deps = deps
    
    def suck_tags( self, node ):
        tags_to_suck = [ 'not_objc', 'signal_set_objc', 'signal_unset_objc' ] # 'future', 'globally', 'cycle' ]
        sucked = [ node.get_tag( x ) for x in tags_to_suck ]
        sucked = [ x for x in sucked if x is not None ]
        self.tags += sucked
        [ node.toggle_tag( x ) for x in sucked ]

    def get_text( self ,collectlist):
        # get the "verb"
        verb = self.dep

        # get the object
        oe = ObjectExtractor()
        obj = oe.extract_str( self.deps, verb )
        
        utext = None
        # if the sentence says that signal was set
        if self.has_tag( Tag( 'signal_set_objc' ) ):
            utext = obj

        # if the sentence says that signal was not set
        elif self.has_tag( Tag( 'signal_unset_objc' ) ):
            self.toggle_tag( Tag( 'not' ) )
            utext = obj
        
        if utext is None:
            return '%s(%s(%s))' % (self.oper_str(), verb.value, obj, )
        else:
            return '%s(%s)' % (self.oper_str(), utext, )

    def get_agent( self ):
        oe = ObjectExtractor()
        obj = oe.extract_str( self.deps )
        return obj


class TTMainClauseNode( TTNode ):
    """Represents main clause where subject is the agent."""
    def __init__( self, phrase ):
        TTNode.__init__( self )
        self.phrase = phrase
    

    def suck_tags( self, node ):
        tags_to_suck = [ 'not', 'signal_set', 'signal_unset','respond_to','move','is_true','is_in','locate','enable','become_true','is_done','is_predicative','is_down'] 
        sucked = [ node.get_tag( x ) for x in tags_to_suck ]
        sucked = [ x for x in sucked if x is not None ]
        self.tags += sucked
        [ node.toggle_tag( x ) for x in sucked ]
    #get predicate ,maybe contain !.
    def get_predicate_collectlist(self,subject,predicate,collectlist):
        str=""
        for collect in collectlist.collectsubprelist:
            if subject==collect.subject:
                if predicate in collect.predicate and not self.predicate_in_collectlist_antonymlist(predicate,collect.antonymPairList):
                    str = "%s_%s"%(predicate,subject)
                elif predicate in collect.predicate and self.predicate_in_collectlist_antonymlist(predicate,collect.antonymPairList):
                    tempStr=""
                    for i in collect.antonymPairList: 
                        if predicate in i.possitivePredicate:
                            tempStr = "%s_%s"%(i.possitivePredicate[0],subject)
                            break
                        elif predicate in i.negativePredicate:
                            tempStr ="!%s_%s"%(i.possitivePredicate[0],subject)
                            break
                    str = tempStr
                break
                    
        return str
    def predicate_in_collectlist_antonymlist(self,predicate,antonymPairList):
        res = False
        for i in antonymPairList:
            if predicate in i.possitivePredicate:
                res = True
            if predicate in i.negativePredicate:
                res = True
            
        return res
        
    def get_text( self ,collectlist):
        if self.has_tag(Tag('move')) or self.has_tag(Tag('locate')):
            str = self.phrase.get_special_object()
            res="%s%s" % (self.oper_str(),str,)
        elif self.has_tag(Tag('respond_to')):
            subjectlist = self.phrase.get_subj_str()
            objectstr =self.phrase.get_special_object()
            subjectstr=""
            for i in subjectlist:
                subjectstr+=i
                
            res="[](%s(%s -> <> %s))"%( self.oper_str(),objectstr,subjectstr)    
        else:
            subjs = self.phrase.get_subj()
            oper = self.get_operators()
            #print "ok100"
            
        # anaphora resolution
        # me = self
        # while True:
        #   if i'm my parent's first node, me = my parent; continue
        #   if i'm my parent's second node, subj = my parent's first node subj
            anaphora = None
            if len( subjs ) == 1:
                subj = subjs[ 0 ]
                if GroupDirectory().in_group( subj.value, 'pronouns' ):
                    me = self
                    anaphora = None
                    while me.parent is not None:
                        if me.parent.children.index( me ) == 0:
                            me = me.parent
                            continue
                        else:
                            asubjs = me.parent.children[ 0 ].get_agent() #phrase.get_subj_str()
                            anaphora = asubjs
                            if not GroupDirectory().in_group( anaphora, 'pronouns' ):
                                break
                            else:
                                me = me.parent
            
            if anaphora is None:
                
                subj_str = self.phrase.get_subj_str()#get_subj_str is list
            else:
                subj_str = anaphora
            
            utext = None 
            
        #
        # UNDERSTANDING HERE
              # by default no understanding
        # if the sentence says that signal was set
            
            if self.has_tag(Tag( 'is_true')) :#modified by CYS in 2013.9.22(line:)
                utext = subj_str
                
            if self.has_tag(Tag( 'is_predicative')) :
                utext = subj_str
                
            if self.has_tag(Tag( 'is_down')) :
                utext = subj_str     
                
            if self.has_tag(Tag( 'is_in')) :
                utext = subj_str 
            
                
            if self.has_tag( Tag( 'signal_set' ) ):
                utext = subj_str
                
            if self.has_tag(Tag( 'become_true')) :
                utext = subj_str  
                
            if self.has_tag(Tag( 'enable')) :
                utext = subj_str

        # if the sentence says that signal was not set
            elif self.has_tag( Tag( 'signal_unset' ) ):
                self.toggle_tag( Tag( 'not' ) )
                utext = subj_str
            

            
        # format the result and output
            if utext is None:
            # default(modified by CYS in 2013.9.22,line(395-397),do not output the "elevator" subject)
                if "elevator" in subj_str:
                    res = "(%s%s)" % ( self.oper_str(), self.phrase.pred.value )
                else:
                    str=""
                    for i in subj_str:
                        if cmp(i,"&&")==0 and "!" in self.oper_str():
                            str+="||"
                        elif cmp(i,"||")==0 and "!" in self.oper_str():
                            str+="&&"
                        elif cmp(i,"&&")==0 and "!" not in self.oper_str():
                            str+=i
                        elif cmp(i,"||")==0 and "!" not in self.oper_str():
                            str+=i
                        else:
                            tempStr=self.get_predicate_collectlist(i,WordStemmer().stemstr(self.phrase.pred),collectlist)
                            if "!" in self.oper_str() and tempStr.find("!")>=0:
                                str += tempStr[1:]
                            elif "!" in self.oper_str() and not tempStr.find("!")>=0:
                                str += "!"+tempStr
                            elif "!" not in self.oper_str():
                                str += tempStr
                                   
                    res = "(%s)" % ( str )
            else:
            # understood
                str=""
                for i in utext:
                    if cmp(i,"&&")==0 and "!" in self.oper_str():
                        str+="||"
                    elif cmp(i,"||")==0 and "!" in self.oper_str():
                        str+="&&"
                    elif cmp(i,"&&")==0 and "!" not in self.oper_str():
                        str+=i
                    elif cmp(i,"||")==0 and "!" not in self.oper_str():
                        str+=i
                    else:
                        str+="%s%s"%(self.oper_str(),i)
                    
                res = "(%s)" % (  str )
        
        return res


class TTBinaryNode( TTNode ):
    operator = None

    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "%s(%s %s %s)" % ( self.oper_str( ), self.children[ndx1].get_text(collectlist), self.operator, self.children[ndx2].get_text(collectlist), )

class TTUntilNode( TTBinaryNode ):
    operator = ""
    
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "[](!(%s) -> ((%s) W (%s)))" % (  self.children[ndx2].get_text(collectlist), self.children[ndx1].get_text(collectlist), self.children[ndx2].get_text(collectlist),)
 

class TTImplNode( TTBinaryNode ):
    operator = "->"
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
            
        containInitial = False
        for i in self.get_temporal_operators_recursive():
            if i.name == 'initial':
                containInitial = True
        if containInitial:
            return "((%s) %s (%s))" % ( self.children[ndx1].get_text(collectlist), self.operator, self.children[ndx2].get_text(collectlist), )
        else:
            return "[]((%s) %s (%s))" % (  self.children[ndx1].get_text(collectlist), self.operator, self.children[ndx2].get_text(collectlist), )


class TTAfterNode( TTBinaryNode ):
    operator = "" #not used.
    
    def get_text( self,collectlist ):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "[](%s -> [](%s))" % (  self.children[ndx2].get_text(collectlist), self.children[ndx1].get_text(collectlist), )


class TTBeforeNode( TTBinaryNode ):
    operator = "" #not used.
    
    def get_text( self,collectlist ):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "(<>(%s) -> ((%s) U (%s)))" % (  self.children[ndx2].get_text(collectlist), self.children[ndx1].get_text(collectlist),self.children[ndx2].get_text(collectlist), )


class TTExistenceUntilNode( TTBinaryNode ):
    operator = ""
    
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "[]((!(%s)) -> (!(%s) U ((%s) && !(%s))))" % (  self.children[ndx2].get_text(collectlist), self.children[ndx2].get_text(collectlist), self.children[ndx1].get_text(collectlist),self.children[ndx2].get_text(collectlist),)
     
class TTExistenceAfterNode( TTBinaryNode ):
    operator = ""
    
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "[](!(%s)) || <> ((%s) && <> (%s))" % (  self.children[ndx2].get_text(collectlist), self.children[ndx2].get_text(collectlist), self.children[ndx1].get_text(collectlist),)
  
         
class TTExistenceBeforeNode( TTBinaryNode ):
    operator = ""
    
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
        
        return "!(%s) W ((%s) && !(%s))" % (  self.children[ndx2].get_text(collectlist), self.children[ndx1].get_text(collectlist), self.children[ndx2].get_text(collectlist),)
  
class TTAndNode( TTBinaryNode ):
    operator = "&&"
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
            
        return "((%s) %s (%s))" % ( self.children[ndx1].get_text(collectlist), self.operator, self.children[ndx2].get_text(collectlist), )
        
    # added by cys in 2013.9.4
class TTOrNode( TTBinaryNode ):
    operator = "||"
    def get_text( self ,collectlist):
        if len( self.children ) < 2:
            sys.stderr.write("<incomplete binary node>") 
            sys.exit(1)

        ndx1 = 0
        ndx2 = 1
        if self.kwargs.get( 'reverse', False ):
            ndx1 = 1
            ndx2 = 0
            
        
        return "((%s) %s (%s))" % ( self.children[ndx1].get_text(collectlist), self.operator, self.children[ndx2].get_text(collectlist), )
      
    # added by cys in 2013.9.4
# want to synthesis "and" sentences and "or" sentences and one of tree contain "if" of "until".
# class TTBuilderConj added by CYS in 2013.9.26.
class TTBuilderConj:
    def builder(self,ttbuilderdict):
        mainTreedict = {}
        #print ttbuilderdict.values()
        #print "ok100"
        for ttbuilderTerm in ttbuilderdict.keys():
            if isinstance(ttbuilderTerm.tt[0],TTUntilNode) or isinstance(ttbuilderTerm.tt[0],TTImplNode) or isinstance(ttbuilderTerm.tt[0],TTAfterNode) or isinstance(ttbuilderTerm.tt[0],TTBeforeNode):
                mainTreedict[ttbuilderTerm] = ttbuilderdict.get(ttbuilderTerm)
                del ttbuilderdict[ttbuilderTerm]
                break
                
        #print ttbuilderdict.values()
        while len(ttbuilderdict.keys())>0:
            for ttbuilderTerm in ttbuilderdict.keys():
                flag = 0
                #mainTreedict contain one element.
                for i in mainTreedict.keys():
                    mainTreeConj = mainTreedict.get(i)
                #print mainTreeConj
                #print ttbuilderdict.values()
                #print "ok107"  
                #get conj.
                notMainTreeConj = ttbuilderdict.get(ttbuilderTerm)
                #for i in mainTreeConj:
                for i in notMainTreeConj:
                    if i == mainTreeConj[0]:
                        #print "ok108"
                        self.inserttreeconj(mainTreedict,ttbuilderTerm,i,notMainTreeConj)
                        del ttbuilderdict[ttbuilderTerm]
                        flag = 1
                        break
                if flag ==1:
                    break
                
              
        ttbuilderdict.update(mainTreedict)
                
            
                
    def inserttreeconj(self,mainTreedict,notMainTree,conjdependency,notMainTreeConjList):
        """The not main tree is inserted into main tree."""
        #merge the conj-typedepency and delete the same conj-typedepency.
        notMainTreeConjList.remove(conjdependency)
        for i in mainTreedict.keys():#mainTree contain one element.
            mainTreedict.get(i).remove(conjdependency)
            for j in notMainTreeConjList:
                mainTreedict.get(i).append(j)
            mainTree = i
        
        matchPreds = []#the Pred Word to tell us the notMainTree where to place it.  
        matchPreds.append(conjdependency.gov)
        matchPreds.append(conjdependency.dep)
        matchPreds.remove(notMainTree.tt[0].phrase.pred)#contain one element.
        #print matchPreds
        
        tracelist = []# need to be traversed.
        tracelist.append(mainTree.tt[0])
        while len(tracelist) > 0:   # can find the difference between for and while.(when use for i in *,it is wrong .)
            #print len(tracelist)
            i = tracelist.pop() 
            if len(i.children) ==2:
                if isinstance(i.children[0],TTTermNode):
                    if i.children[0].phrase.pred in matchPreds :
                        if not isinstance(i,TTAndNode) and not isinstance(i,TTOrNode):
                            originalTTermNode = i.children[0]
                            i.children.remove(originalTTermNode)
                            if conjdependency.reln_specific == "and":
                                ttAndNode = TTAndNode()
                                ttAndNode.add_child(originalTTermNode)
                                ttAndNode.add_child(notMainTree.tt[0])
                                i.children.insert(0,ttAndNode)
                                ttAndNode.parent=i
                                break
                            elif conjdependency.reln_specific == "or":
                                ttOrNode = TTOrNode()
                                ttOrNode.add_child(originalTTermNode)
                                ttOrNode.add_child(notMainTree.tt[0])
                                i.children.insert(0,ttOrNode)
                                ttOrNode.parent=i
                                break
                            else:
                                sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                break
                        else:
                            #process if A is true and B is true or C is true,D is true.find not andNode and Ornode.
                            me=i
                            while isinstance(me.parent,TTAndNode) or isinstance(me.parent,TTOrNode):
                                me=me.parent
                            
                            if me.parent.children.index(me)==0:
                                if(isinstance(me.parent,TTImplNode)and not me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTUntilNode) and me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTAfterNode) and me.parent.kwargs.has_key('reverse') ) or (isinstance(me.parent,TTBeforeNode) and me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceUntilNode) and me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTExistenceAfterNode) and me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceBeforeNode)and me.parent.kwargs.has_key('reverse')):
                                    father=me.parent
                                    father.children.remove(me)
                                    if conjdependency.reln_specific == "and":
                                        ttAndNode = TTAndNode()
                                        ttAndNode.add_child(me)
                                        ttAndNode.add_child(notMainTree.tt[0])
                                        father.children.insert(0,ttAndNode)
                                        ttAndNode.parent = father
                                        break
                                    elif conjdependency.reln_specific == "or":
                                        ttOrNode = TTOrNode()
                                        ttOrNode.add_child(me)
                                        ttOrNode.add_child(notMainTree.tt[0])
                                        father.children.insert(0,ttOrNode)
                                        ttOrNode.parent = father
                                        break
                                    else:
                                        sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                        break
                                elif (isinstance(me.parent,TTImplNode)and me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTUntilNode) and not me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTAfterNode) and not me.parent.kwargs.has_key('reverse') ) or (isinstance(me.parent,TTBeforeNode) and not me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceUntilNode) and not me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTExistenceAfterNode) and not me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceBeforeNode)and not me.parent.kwargs.has_key('reverse')):
                                    originalTTermNode = i.children[0]
                                    i.children.remove(originalTTermNode)
                                    if conjdependency.reln_specific == "and":
                                        ttAndNode = TTAndNode()
                                        ttAndNode.add_child(originalTTermNode)
                                        ttAndNode.add_child(notMainTree.tt[0])
                                        i.children.insert(0,ttAndNode)
                                        ttAndNode.parent=i
                                        break
                                    elif conjdependency.reln_specific == "or":
                                        ttOrNode = TTOrNode()
                                        ttOrNode.add_child(originalTTermNode)
                                        ttOrNode.add_child(notMainTree.tt[0])
                                        i.children.insert(0,ttOrNode)
                                        ttOrNode.parent=i
                                        break
                                    else:
                                        sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                        break
                            elif me.parent.children.index(me)==1:
                                father=me.parent
                                father.children.remove(me)
                                if conjdependency.reln_specific == "and":
                                    ttAndNode = TTAndNode()
                                    ttAndNode.add_child(me)
                                    ttAndNode.add_child(notMainTree.tt[0])
                                    father.children.insert(1,ttAndNode)
                                    ttAndNode.parent = father
                                    break
                                elif conjdependency.reln_specific == "or":
                                    ttOrNode = TTOrNode()
                                    ttOrNode.add_child(me)
                                    ttOrNode.add_child(notMainTree.tt[0])
                                    father.children.insert(1,ttOrNode)
                                    ttOrNode.parent = father
                                    break
                                else:
                                    sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                    break
                                
                
                else:
                    tracelist.append(i.children[0])
                    
                if isinstance(i.children[1],TTTermNode):
                    if i.children[1].phrase.pred in matchPreds :
                        if not isinstance(i,TTAndNode) and not isinstance(i,TTOrNode):
                            originalTTermNode = i.children[1]
                            i.children.remove(originalTTermNode)
                            if conjdependency.reln_specific == "and":
                                ttAndNode = TTAndNode()
                                ttAndNode.add_child(originalTTermNode)
                                ttAndNode.add_child(notMainTree.tt[0])
                                i.children.insert(1,ttAndNode)
                                ttAndNode.parent=i
                                break
                            elif conjdependency.reln_specific == "or":
                                ttOrNode = TTOrNode()
                                ttOrNode.add_child(originalTTermNode)
                                ttOrNode.add_child(notMainTree.tt[0])
                                i.children.insert(1,ttOrNode)
                                ttOrNode.parent=i
                                break
                            else:
                                sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                break
                        else:
                            #process if A is true and B is true or C is true,D is true.find not andNode and Ornode.
                            me=i
                            while isinstance(me.parent,TTAndNode) or isinstance(me.parent,TTOrNode):
                                me=me.parent
                            
                            if me.parent.children.index(me)==0:
                                if(isinstance(me.parent,TTImplNode)and not me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTUntilNode) and me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTAfterNode) and me.parent.kwargs.has_key('reverse') ) or (isinstance(me.parent,TTBeforeNode) and me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceUntilNode) and me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTExistenceAfterNode) and me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceBeforeNode)and me.parent.kwargs.has_key('reverse')):
                                    father=me.parent
                                    father.children.remove(me)
                                    if conjdependency.reln_specific == "and":
                                        ttAndNode = TTAndNode()
                                        ttAndNode.add_child(me)
                                        ttAndNode.add_child(notMainTree.tt[0])
                                        father.children.insert(0,ttAndNode)
                                        ttAndNode.parent = father
                                        break
                                    elif conjdependency.reln_specific == "or":
                                        ttOrNode = TTOrNode()
                                        ttOrNode.add_child(me)
                                        ttOrNode.add_child(notMainTree.tt[0])
                                        father.children.insert(0,ttOrNode)
                                        ttOrNode.parent = father
                                        break
                                    else:
                                        sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                        break
                                elif (isinstance(me.parent,TTImplNode)and me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTUntilNode) and not me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTAfterNode) and not me.parent.kwargs.has_key('reverse') ) or (isinstance(me.parent,TTBeforeNode) and not me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceUntilNode) and not me.parent.kwargs.has_key('reverse'))or (isinstance(me.parent,TTExistenceAfterNode) and not me.parent.kwargs.has_key('reverse')) or (isinstance(me.parent,TTExistenceBeforeNode)and not me.parent.kwargs.has_key('reverse')):
                                    originalTTermNode = i.children[1]
                                    i.children.remove(originalTTermNode)
                                    if conjdependency.reln_specific == "and":
                                        ttAndNode = TTAndNode()
                                        ttAndNode.add_child(originalTTermNode)
                                        ttAndNode.add_child(notMainTree.tt[0])
                                        i.children.insert(1,ttAndNode)
                                        ttAndNode.parent=i
                                        break
                                    elif conjdependency.reln_specific == "or":
                                        ttOrNode = TTOrNode()
                                        ttOrNode.add_child(originalTTermNode)
                                        ttOrNode.add_child(notMainTree.tt[0])
                                        i.children.insert(1,ttOrNode)
                                        ttOrNode.parent=i
                                        break
                                    else:
                                        sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                        break
                            elif me.parent.children.index(me)==1:
                                father=me.parent
                                father.children.remove(me)
                                if conjdependency.reln_specific == "and":
                                    ttAndNode = TTAndNode()
                                    ttAndNode.add_child(me)
                                    ttAndNode.add_child(notMainTree.tt[0])
                                    father.children.insert(1,ttAndNode)
                                    ttAndNode.parent = father
                                    break
                                elif conjdependency.reln_specific == "or":
                                    ttOrNode = TTOrNode()
                                    ttOrNode.add_child(me)
                                    ttOrNode.add_child(notMainTree.tt[0])
                                    father.children.insert(1,ttOrNode)
                                    ttOrNode.parent = father
                                    break
                                else:
                                    sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
                                    break
                                
                
                else:
                    tracelist.append(i.children[1])
                    
                
                
               
            else:
                sys.stderr.write( "the mainTree is wrong!")
                sys.exit(1)
            
          
    
         
        
class TTBuilderConjAllTTerm:
    """"""
    def builder(self,ttbuilderdict):
        mainTreedict = {}
        #print ttbuilderdict.values()
        #get the first element for mainTreedict.
        
        index=0
        mainbuilderTerm=None
        for ttbuilderTerm in ttbuilderdict.keys():
            if index==0:
                mainbuilderTerm=ttbuilderTerm
                index=ttbuilderTerm.tt[0].phrase.pred.index
            elif ttbuilderTerm.tt[0].phrase.pred.index<index:
                mainbuilderTerm=ttbuilderTerm
                index=ttbuilderTerm.tt[0].phrase.pred.index
        
        mainTreedict[mainbuilderTerm]=ttbuilderdict.get(mainbuilderTerm)  
        del ttbuilderdict[mainbuilderTerm]
                        
        #print ttbuilderdict.values()
        while len(ttbuilderdict.keys())>0:
            for ttbuilderTerm in ttbuilderdict.keys():
                flag = 0
                #mainTreedict contain one element.
                mainTreeConj=[]
                for i in mainTreedict.keys():
                    mainTreeConj = mainTreedict.get(i) 
                #get conj.
                notMainTreeConj = ttbuilderdict.get(ttbuilderTerm)
                #for i in mainTreeConj:
                for i in notMainTreeConj:
                    if i == mainTreeConj[0]:
                        #print "ok108"
                        self.inserttreeconj(mainTreedict,ttbuilderTerm,i,notMainTreeConj)
                        del ttbuilderdict[ttbuilderTerm]
                        flag = 1
                        break
                if flag ==1:
                    break
                
              
        ttbuilderdict.update(mainTreedict)
                
            
                
    
    def inserttreeconj(self,mainTreedict,notMainTree,conjdependency,notMainTreeConjList):
        """The not main tree is inserted into main tree."""
        #merge the conj-typedepency and delete the same conj-typedepency.
        notMainTreeConjList.remove(conjdependency)
        for i in mainTreedict.keys():#mainTree contain one element.
            mainTreedict.get(i).remove(conjdependency)
            for j in notMainTreeConjList:
                mainTreedict.get(i).append(j)
            mainTree = i
            
        if conjdependency.reln_specific == "and":
            ttAndNode = TTAndNode()
            ttAndNode.add_child(mainTree.tt[0])
            ttAndNode.add_child(notMainTree.tt[0])
            mainTree.tt.remove(mainTree.tt[0])
            mainTree.tt.insert(0,ttAndNode)
        elif conjdependency.reln_specific == "or":
            ttOrNode = TTOrNode()
            ttOrNode.add_child(mainTree.tt[0])
            ttOrNode.add_child(notMainTree.tt[0])
            mainTree.tt.remove(mainTree.tt[0])
            mainTree.tt.insert(0,ttOrNode)
        else:
            sys.stderr.write("the conj of sentences are not and-conj ,or-conj.")
        
         
class TTBuilder:
    tt = None
    def build( self, plist ):
        # build nodelist out of plist
        self.tt = nlist = [ TTTermNode( p ) for p in plist ]
        
        synths = synth.__SYNTHESIZERS__ 
        synths_instances = [ sth() for sth in synths ]
        
        while len( nlist ) > 1:
            thisround = any( [ sth.synth( nlist ) for sth in synths_instances ] )
            # the temporal tree has been finished.
            if not thisround:
                return False

        #print nlist[0].children[0].resnode.tags
        #print nlist[0].children[1].tags
        return True

    def get_tt( self ):
        if len( self.tt ) == 1:
            return self.tt[ 0 ]
        else:
            raise Exception( "TT hasn't been built yet" )
