#!/usr/bin/python
#
# author: Yesheng Chai
# date: 2013.11.11


# import standard python libs
import os, sys, re, warnings, copy
import config
from optparse import OptionParser
from ttlib.translator import *

# disable python warnings about deprecated functions (mainly because of jpype)
warnings.filterwarnings("ignore")

# check python version
if sys.version_info < (2, 6):
    print 'Warning: You are running Python %d.%d. The program is intended to run in Python >=2.6, therefore you may encounter problems.' % ( sys.version_info[0], sys.version_info[1], )


# import our libs
from ttlib import *
from ttlib.helper import _

# IMPORT LIBRARIES
# import lib
import jpype
import yaml


if __name__ == "__main__":
    # parse commandline parameters
    oparser = OptionParser()
    oparser.add_option("-I", "--inputfile", action = "store", default = None,
                  help="load sentences from file",)
    oparser.add_option("-O","--outputfile", action = "store", default = None,
                  help="output generated formulas to file",)
    oparser.add_option("-d", "--debug", action = "store_true", default = False,
                  help="run in debugging mode",)
    
    (options, args) = oparser.parse_args()
    helper.DEBUG = options.debug
    
    debug(  _( 'Program started.' ) )
    
    # load the standford parser libraries through jpype
    ous = OutSuppresser( sys.stdout )  #helper
    ous.suppress( )
    jvmPath = jpype.getDefaultJVMPath()
    if jvmPath.find("libjvm.so")>=0 or jvmPath.find("libjvm.dylib")>= 0:
        jpype.startJVM( jvmPath, "-Djava.class.path=src/specc/translator/stanford-parser.jar", "-Xmx500m" )
    else:
        if config.java_bin.find("libjvm.so")>=0 or config.java_bin.find("libjvm.dylib")>=0:
            jpype.startJVM( config.java_bin, "-Djava.class.path=src/specc/translator/stanford-parser.jar", "-Xmx500m" )
        else:
            sys.stderr.write("Unable to obtain javabin path automatically and please pecify path to your Java JVM library (libjvm.so or jvm.dll or libjvm.dylib) in config.py file.")
    ous.revert()
    
    # create instance of the translator
    tt = TemporalTranslator()
    
                                     
    # if the user didn't specify a file on cmdline, load sentences from
    # cmdline arguments and translate them .
    #modified by CYS in 2013.9.5(line:104-148)
    if options.inputfile is None:
        if options.outputfile is None:
            for s in args:
               res_formula,input_formula,output_formula = tt.translate( s )
               print res_formula
               print input_formula
               print output_formula
               
        else:
            output=open(options.outputfile,'w')
            for s in args:
                res_formula,input_formula,output_formula = tt.translate( s )
                output.write( res_formula )
                output.write('\n')
                output.write ( input_formula )
                output.write('\n')
                output.write ( output_formula )
                output.write('\n')
                
        # otherwise load sentences from files
    else:
        #get Antonym list from dictionary.
        antonymDictFile = open('src/specc/translator/antonymDict.txt')
        #collect AntonymList from Dict.
        collectAntonymList = AntonymList()
        #initial
        collectAntonymList.antonymList=[]
        for line in antonymDictFile:
            line=line.strip()
            collectAntonym = Antonym()
            #initial
            collectAntonym.wordList=[]
            collectAntonym.oppositeWordList=[]
            tempList = line.split(',')
            #the length of tempList is 2.
            collectAntonym.wordList.extend(tempList[0].split('&'))
            collectAntonym.oppositeWordList.extend(tempList[1].split('&'))
            collectAntonymList.antonymList.append(collectAntonym)
        antonymDictFile.close()
        #get subject and predicate from sentance.
        inputpre = open(options.inputfile)
        parser = StanfordParser()
        ppd = PhrasePatternDirectory()
        gd = GroupDirectory()
        collectlist = CollectSubPreList()#important
        collectlist.collectsubprelist=[]
        predicateList =[]#important
        for ln in inputpre:
            ln=ln.strip()
            if '##' in ln or len(ln)==0:
                    continue
            else:
                parse = parser.parse( ln )
                disjuncter = Disjuncter()
                #ds_structs contain independent etmporal units(depencies) and conjs contain conj 
                ds_structs, conjs = disjuncter.disjunct( parse.get_dependencies() )
                for ds in ds_structs: 
                    sentencesep = SentenceSeparator()
                    phrases = sentencesep.separate( ds )
                    for phrase in phrases:
                        tempPredicate = WordStemmer().stemstr(phrase.pred)
                        if not tempPredicate=="true" and not tempPredicate=="false" and not tempPredicate in predicateList:
                            predicateList.append(tempPredicate)
                        for subject in phrase.get_subj():
                            if not collectlist.search(subject.value):
                                collect = CollectSubPre()#important
                                #important
                                collect.predicate = []
                                collect.antonymPairList =[]
                                collect.subject = subject.value
                                # get predicate from phrase.
                                if not tempPredicate=="true" and not tempPredicate=="false":
                                    if not ppd.haspredicate(tempPredicate):
                                        collect.predicate .append(tempPredicate)
                                #print len(collect.predicate)
                                collectlist.collectsubprelist.append(collect)
                            else:
                                for i in collectlist.collectsubprelist:
                                    if i.subject == subject.value:
                                        if not tempPredicate=="true" and not tempPredicate=="false":
                                            if not tempPredicate in i.predicate and not ppd.haspredicate(tempPredicate):
                                                i.predicate.append(tempPredicate)
         
        #for i in collectlist.collectsubprelist:
            #print i.subject
            #print i.predicate
        
        cPredicateTermList = PredicateTermList()
        cPredicateTermList.predicateTermList = []
        for i in predicateList:
            cPredicateTerm = PredicateTerm()
            #initial
            cPredicateTerm.predicate=""
            cPredicateTerm.antonymDict=[]
            cPredicateTerm.antonymFile=[]
            cPredicateTerm.flag = 0
            cPredicateTerm.color=""
            #assign the value to cPredicateTerm.
            cPredicateTerm.predicate = i
            cPredicateTerm.antonymDict.extend(collectAntonymList.find_antonymlist(i))
            cPredicateTerm.antonymFile.extend([val for val in predicateList if val in cPredicateTerm.antonymDict])
            if len(cPredicateTerm.antonymFile)>0:
                cPredicateTerm.color="blue"
            else:
                cPredicateTerm.color="red"
            cPredicateTermList.predicateTermList.append(cPredicateTerm)
        
        cAssignFlag = AssignFlag()
        for i in cPredicateTermList.predicateTermList:
            if i.color=="red" or i.flag !=0:
                continue
            else:
                i.flag = 1
                cAssignFlag.assignflag(cPredicateTermList,i.antonymFile,1)
        #for i in cPredicateTermList.predicateTermList:
             #print i.predicate
             #print i.antonymDict
             #print i.antonymFile
             #print i.color
             #print i.flag
        for i in collectlist.collectsubprelist:
            addedPredicateDict = {}#the predicate in predicate has been added addedPredicateDict and the value is false.
            for j in i.predicate:
                addedPredicateDict[j]=False
                
            for j in i.predicate:
                cElementForCsubpre=ElementForCsubpre()
                cElementForCsubpre.possitivePredicate=[]
                cElementForCsubpre.negativePredicate=[]
                if addedPredicateDict[j]==False:
                    #justify the predicate in addedPredicateDict true of false.
                    addedPredicateDict[j]=True
                    antonym_from_cPredicateTermList =[]
                    for term in cPredicateTermList.predicateTermList:
                        if j==term.predicate:
                            #get antonym of predicate j.
                            antonym_from_cPredicateTermList.extend([val for val in i.predicate if val in term.antonymFile])
                    if len(antonym_from_cPredicateTermList)>0:
                        #put the j in antonymList(one vs one).
                        for term1 in cPredicateTermList.predicateTermList:
                            if j==term1.predicate:
                                if term1.flag ==1:
                                    cElementForCsubpre.possitivePredicate.append(j)
                                elif term1.flag ==-1:
                                    cElementForCsubpre.negativePredicate.append(j)
                        #put the antonym of j in antonymList.
                        for term1 in antonym_from_cPredicateTermList:
                            addedPredicateDict[term1]=True
                            for term2 in cPredicateTermList.predicateTermList:
                                if term1==term2.predicate:
                                    if term2.flag ==1:
                                        cElementForCsubpre.possitivePredicate.append(term1)
                                    elif term2.flag ==-1:
                                        cElementForCsubpre.negativePredicate.append(term1)
                        i.antonymPairList.append(cElementForCsubpre)
       
        inputpre.close()
        input = open( options.inputfile )
        if options.outputfile is None:
           for ln in input:
               ln = ln.strip()
               if '##' in ln or len(ln)==0:
                    continue
               else:
                    res_formula,input_formula,output_formula = tt.translate( ln ,collectlist)
                    print res_formula
                    print input_formula
                    print output_formula

        
        else:
            output=open(options.outputfile,'w')
            for ln in input:
               ln = ln.strip()
               res_formula,input_formula,output_formula = tt.translate( ln )
               output.write( res_formula )
               output.write('\n')
               output.write ( input_formula )
               output.write('\n')
               output.write ( output_formula )
               output.write('\n')
            
            
    # shutdown the standford parser libraries bindings
    ous = OutSuppresser( sys.stderr )
    ous.suppress()
    jpype.shutdownJVM( )
    ous.revert()
  

