from groups import *
from parser import *
from patterns import *

class Understanding:
    def __init__( self ):
        self.ums = __UNDERSTANDING_MODULES__

    def understand( self, phrase, node, pred = None, agent_str = None ):
        # get predicate if not supplied
        if pred is None:
            pred = phrase.get_pred()
            pred.value = WordStemmer().stemstr( pred )

        # go through understanding modules and find a suitable one, 
        # if none suitable found, do nothing, otherwise launch it
        found_um = None
        for um in self.ums:
            for g in um.verb_group:
                if GroupDirectory().in_group( pred.value, g ):
                    found_um = um
                    break

        if found_um is not None:
            inst = found_um( phrase, node, pred, agent_str )
            inst.process()
            return inst.get_text()
        return None


class UBase:
    verb_group = []

    def __init__( self, phrase, node, pred, agent_str ):
        self.phrase = phrase
        self.node = node
        self.pred = pred
        self.agent_str = agent_str

class USignalSet( UBase ):
    verb_group = [ 'signal_set' ]

    def process( self ):
        pass

    def get_text( self ):
        if self.agent_str is None:
            return self.phrase.get_subj_str()
        else:
            return agent_str

class USignalUnset( UBase ):
    verb_group = [ 'signal_unset' ]

    def process( self ):
        self.node.toggle_tag( Tag( 'not' ) )


    def get_text( self ):
        if self.agent_str is None:
            return self.phrase.get_subj_str()
        else:
            return agent_str



__UNDERSTANDING_MODULES__ = [ USignalSet, USignalUnset, ]
