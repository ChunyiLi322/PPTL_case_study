#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: groups.py - tools for working with synonyme groups
import yaml

class GroupDirectory:
    __instance = None
    
    # singleton implementation; makes sure that there exists just one 
    # instance of this class throughout the whole program
    def __new__( cls, *args, **kwargs ):
        if GroupDirectory.__instance is None:
            return super( GroupDirectory, cls ).__new__(cls, *args, **kwargs )
        else:
            return TemporalTranslator.__instance

    def __init__( self, file = "src/specc/translator/groups.yaml" ):
        # load groups from yaml configuration file
        self.load_yaml( file )
    
    def load_yaml( self, file ):
        try:
            f = open( file, 'rb' )
            ys = yaml.load( f.read() )
            
        except IOError:
            err( _( 'Error saving file "%s" with patterns' ) % file )
        
        self.gdict = ys

    def get_group( self, group ):
        """Get the list of words in this group."""
        return self.gdict.get( group, None )

    def in_group( self, what, group ):        
        """Check if word @what is in @group synonyme group."""
        if self.gdict.has_key( group ):
            return what in self.gdict.get( group, None )
        return False

# for testing purposes
if __name__ == "__main__":
    print GroupDirectory().in_group( 'set', 'signal_set' )

