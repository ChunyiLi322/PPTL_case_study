#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: helper.py - helper methods

import os

# placeholder for localization
def _( s ):
    return s

# console coloring
_colors = { 'gray' : 30, 'red' : 31, 'green' : 32, 'yellow' : 33, 'blue' : 34, 'magneta' : 35, 'cyan' : 36,
            'white' : 37, 'crimson' : 38, 'hred' : 41, 'hgreen' : 42, 'hgreen' : 43, 'hbrown' : 43,
            'hblue' : 44, 'hmagneta' : 45, 'hcyan' : 46, 'hgray' : 47, 'hcrimson' : 48 }
def color( col, s, bold = False ):
    return "\033[%d;%dm%s\033[1;m" % ( bold is True and 1 or 0, _colors[ col ], s, )

DEBUG = False # False
# placeholders for printing to console
def out( s ): print s
def err( s ): print >>sys.stderr, s
def dbg( s ): err( color( "green", "DEBUG: %s" % s ) )
def msg( s ): out( color( 'blue', '>>> %s' % s ) )
def debug( s ): 
    if DEBUG: 
        msg( s )

# convert text2int
# source: stackoverflow.com 
# author: recursive
# modified
def text2int(textnum, numwords={}):
    if textnum.strip().lower() == "next":
        return 1
    if not numwords:
        units = [
        "zero", "one", "two", "three", "four", "five", "six", "seven", "eight",
        "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen",
        "sixteen", "seventeen", "eighteen", "nineteen",
        ]

        tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]

        scales = ["hundred", "thousand", "million", "billion", "trillion"]

        numwords["and"] = (1, 0)
        for idx, word in enumerate(units):  numwords[word] = (1, idx)
        for idx, word in enumerate(tens):       numwords[word] = (1, idx * 10)
        for idx, word in enumerate(scales): numwords[word] = (10 ** (idx * 3 or 2), 0)

    ordinal_words = {'first':1, 'second':2, 'third':3, 'fifth':5, 'eighth':8, 'ninth':9, 'twelfth':12}
    ordinal_endings = [('ieth', 'y'), ('th', '')]

    textnum = textnum.replace('-', ' ')

    current = result = 0
    for word in textnum.split():
        if word in ordinal_words:
            scale, increment = (1, ordinal_words[word])
        else:
            for ending, replacement in ordinal_endings:
                if word.endswith(ending):
                    word = "%s%s" % (word[:-len(ending)], replacement)

            if word not in numwords:
                raise Exception("Illegal word: " + word)

            scale, increment = numwords[word]
        current = current * scale + increment
        if scale > 100:
            result += current
            current = 0

    return result + current

class OutSuppresser:
    """Wrapper for suppressing output to a file temporarly (useful for stderr, stdout, ...)."""
    def __init__( self, out ):
        self.out = out

    def suppress( self ):
        """Starts suppressing the output (writes to devnull instead)."""
        self.out.flush()
        self.err = open( os.devnull, 'a+', 0)
        self.olderr = os.dup(self.out.fileno() )
        os.dup2(self.err.fileno(), self.out.fileno())

    def revert( self ):
        """Reverts to the original output."""
        os.dup2( self.olderr, self.out.fileno())
        self.err.close()

