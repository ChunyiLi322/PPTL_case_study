#!/usr/bin/python
# file: config.py - configuration of the translator
#java_bin = "/Library/Java/JavaVirtualMachines/jdk1.7.0_45.jdk/Contents/Home/jre/lib/server/libjvm.dylib"
##=======
java_bin = "/Users/yrj/software/jre1.7.0_25.jre/Contents/Home/lib/server/libjvm.dylib"
##>>>>>>> .r284


