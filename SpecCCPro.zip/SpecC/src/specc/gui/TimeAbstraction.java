/* SPecCC: Specification Consistency Checking
 *
 * Copyright (c) 2014, Rongjie Yan, 
 * All rights reserved.
    
 * This file is part of SpecCC.

 * SpecCC is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 *  SpecCC is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with SpecCC.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package specc.gui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author yrj
 */
public class TimeAbstraction {
    protected int abstractNext(ArrayList<NextPosition> globalNextOperator, int allowedBound){
        
        int maxfactor = 1;
        int numberofBits = 6;
        //int tmpgcd = countingAbstraction(globalNextOperator);
        if (globalNextOperator.isEmpty()|| isOneNext(globalNextOperator))
            return maxfactor;

        String srcYices = generatingYicesInput(globalNextOperator,numberofBits,allowedBound);
        
        String tileYices = "(check)\n" + 
                           "(eval f)\n" ;//+ "(eval sumerror)";
        String yicesFile = "nextConstraints.ys";
        String osName = System.getProperty("os.name");
        String relativelyPath=System.getProperty("user.dir");
        String comm = "";
        if (osName.contains("Mac")){
            comm = relativelyPath+"/yices "+relativelyPath+ "/"+yicesFile;
        }
        else if (osName.contains("Linux")){
            comm = relativelyPath+"/yices_linux "+relativelyPath+ "/"+yicesFile;
        }
        else if (osName.contains("Window")){
          comm = relativelyPath+"/yices.exe "+relativelyPath+ "/"+yicesFile;
        }
        
        BufferedWriter writer = null;
        boolean resultSat = true;
        int tempfactor = 1;
        int errorBound = allowedBound;
        int returnedError = allowedBound;
        int iterNum = 0;
        while (resultSat){
            //create the file
            try{   
                writer = new BufferedWriter(new FileWriter(yicesFile));
                writer.write(srcYices);
                writer.write(tileYices);
                writer.newLine();
                } catch (IOException e) {
            } finally {
                try {
                    if (writer != null) {
                        writer.close();
                    }
                } catch (IOException e) {
                }
            }
            String s = "";	
            Runtime rt = Runtime.getRuntime();
            Process p1;
            try {
                p1 = rt.exec(comm);
                InputStreamReader ir = new InputStreamReader(p1.getInputStream());
		BufferedReader stdInput = new BufferedReader(ir);
                p1.waitFor();
                int i =0;
                while ((s = stdInput.readLine()) != null) {
                            if (i == 0 && s.trim().contains("unsat")) {
                                resultSat = false;
                                break;
                            }
                            else {
                                String tempLine = s.trim();
                                //String binarySrc = "";
                                if (i == 1){ // && tempLine.contains("f"))
                                    s = tempLine.substring(tempLine.indexOf("0b")+2, tempLine.length()).trim();
                                    tempfactor = Integer.valueOf(s,2);                                
                                }/*else if (i==2 ){ //&& tempLine.contains("sumerror"))
                                    s = tempLine.substring(tempLine.indexOf("0b")+2, tempLine.length()).trim();
                                    returnedError = Integer.valueOf(s,2);                                
                                }*/
                            }
                            i++;
                        }
		ir.close();
		p1.destroy();
		/*if(s.length()==0){
			System.out.println("!!! no yices results ");
		}*/
            } catch (IOException e1) {
		e1.printStackTrace();
            }
            catch (InterruptedException e2) {
		e2.printStackTrace();
            }
            
            if (resultSat){
                returnedError = countErrorBound(tempfactor, globalNextOperator);
                if (returnedError <= errorBound && maxfactor < tempfactor){
                    errorBound = returnedError;
                    maxfactor = tempfactor;
                }
                else {
                    if (maxfactor<tempfactor && returnedError <= allowedBound)
                        maxfactor = tempfactor;
                }
                srcYices += "(define V" + iterNum + " :: BV (mk-bv " + numberofBits + " " + tempfactor + "))\n";
                srcYices += "(assert (not (= f "+ "V" + iterNum + ")))\n";
                iterNum ++;
            } 
        }
            
        return maxfactor;
    }
    
    int countErrorBound(int tempfactor, ArrayList<NextPosition> globalNextOperator){
        int errorBound = 0; 
        for (int i =0; i < globalNextOperator.size(); i++){
            errorBound +=  globalNextOperator.get(i).getLength() % tempfactor;
        }
        return errorBound;
    }
    static int gcd(int a, int b) {
        int t;
        if (a < b) {
         t = a;
         a = b;
         b = t;
        }
        if (b == 0)
         return a;
        return gcd(b, a % b);
    }  
    
    protected int countingGCD(ArrayList<NextPosition> nextArray){
    
        int nextgcd = nextArray.get(0).length;

        for (int i = 1; i < nextArray.size(); i++){
            nextgcd = gcd(nextgcd, nextArray.get(i).length);
        }
        return nextgcd;
    }
    
    protected int countingReduction(HashMap<Integer, ArrayList<NextPosition>> transformedNext, HashMap<Integer, Boolean> hasNext){
        int globalGCD =0;
        int initNext = -1;
        HashMap<Integer, Integer> nextGCD = new HashMap<Integer, Integer>();

        for (int i=0; i< hasNext.size(); i++){
            if (hasNext.get(i))
                nextGCD.put(i,countingGCD(transformedNext.get(i)));     
        }
        for (int i=0; i< hasNext.size(); i++){
            if (hasNext.get(i)){
                initNext = i;   
                break;
            }
        }

        if(initNext>=0){
            globalGCD = nextGCD.get(initNext);
            for (int i=initNext+1; i< hasNext.size(); i++){
                if (hasNext.get(i))
                globalGCD = gcd(globalGCD, nextGCD.get(i)); 
            }
        }
        return globalGCD;
    }
    
    
    protected int countingAbstraction(ArrayList<NextPosition> globalNextOperator){
        int tempgcd = 0;
        if (globalNextOperator.size() > 2){
            int midPos = globalNextOperator.size()/2;
            int distanceL = globalNextOperator.get(midPos).getLength()-globalNextOperator.get(0).getLength();
            int distanceU = globalNextOperator.get(globalNextOperator.size()-1).getLength()-globalNextOperator.get(midPos).getLength();
            if (distanceL < distanceU){
                tempgcd = distanceU/(globalNextOperator.size()-midPos);
            }else{
                tempgcd = distanceL/(midPos);
            }


        }
        else
            if(globalNextOperator.size()>0) {
                tempgcd = globalNextOperator.get(0).getLength();
        }
        if (tempgcd == 0)
            tempgcd =1;
        return tempgcd;
    }
    
    protected boolean isOneNext(ArrayList<NextPosition> globalNextOperator){
        for(int i=0; i< globalNextOperator.size(); i ++)
            {
                if (globalNextOperator.get(i).getLength()>1)
                    return false;
            }
        return true;
    
    } 
    
    protected ArrayList<NextPosition> countingNextOperator(String formula, int index){
        ArrayList<NextPosition> nextArray= new ArrayList<NextPosition>();
        int tempPos=0;
        int initialPos = 0;
        int nextSize =0;
        String newFormula = formula; 
        //boolean flag = ;
        while (newFormula.indexOf("X")>=0){
            //flag = true;
            tempPos = newFormula.indexOf("X");
            NextPosition newNext= new NextPosition(); 

            if (tempPos != 0 || nextSize==0){
                newNext.pos = tempPos + initialPos;
                newNext.length = 1;
                newNext.index = index;
                nextArray.add(newNext);
                initialPos = newNext.pos + 1;
                nextSize++;
            }
            else{
                newNext = nextArray.get(nextSize-1);
                newNext.length++;
                initialPos ++;
                nextArray.set(nextSize-1, newNext);
            }

            newFormula = newFormula.substring(tempPos+1);        
        } 
        return nextArray;
    }
    
   
   protected String tofixedBinary(int n, int numberofBits){
       String strBinary = "";
       
       String shortBinary = Integer.toBinaryString(n);
       int lengthBinary = shortBinary.length();
       if (lengthBinary > numberofBits)
           return strBinary;
       else{
           for (int i=0; i< (numberofBits - lengthBinary); i++){
               strBinary += "0"; 
           }
           strBinary += shortBinary;
           strBinary = "0b" + strBinary; 
       }
       return strBinary;
   }
   protected String  generatingYicesInput(ArrayList<NextPosition> globalNextOperator, int numberofBits, int expectedError){
       String srcYices = "(define-type BV (bitvector " + numberofBits + "))\n\n";
       srcYices += "(define Bound :: BV (mk-bv " + numberofBits + " " + expectedError + "))\n";
       srcYices += "(define Zero :: BV (mk-bv " + numberofBits + " 0))\n";
       
       srcYices += "\n";
       srcYices += "(define f :: BV)\n";
       srcYices += "(define sumerror :: BV)\n";
       
       srcYices += "\n";
       
       
       for (int i = 0; i < globalNextOperator.size(); i ++){
           srcYices += "(define T" + i + " :: BV (mk-bv " + numberofBits + " " +
                   globalNextOperator.get(i).getLength()+ "))\n";
       }
       srcYices += "\n";
       
              
       for (int i = 0; i < globalNextOperator.size(); i ++){
           srcYices += "(define t" + i + " :: BV)\n";
       }
       srcYices += "\n";
       for (int i = 0; i < globalNextOperator.size(); i ++){
           srcYices += "(define d" + i + " :: BV)\n";
       }
 
       srcYices += "\n";
       //define Ti = f * ti + di
       for (int i = 0; i < globalNextOperator.size(); i ++){
           srcYices += "(assert (= T" + i + "(bv-add (bv-mul t" + i + " f) d" + i + ")))\n";           
       }
       srcYices += "\n";
       //constraints on \Sigma di \leq Bound
       String srcSum = "d0";
       
       for (int i = 1; i < globalNextOperator.size(); i ++){
           srcSum = "(bv-add d" + i + " " + srcSum + ")";
       }
       srcYices += "(assert (= sumerror" +  srcSum + "))\n";
       srcYices += "(assert (bv-le sumerror Bound))\n";
       srcYices += "\n";
       
       //constraints on 0\leq ti\leq Ti
       for (int i = 0; i < globalNextOperator.size(); i ++){
           srcYices += "(assert (and (bv-le  t" + i + " T" + i+ ") (bv-ge t" + i + " Zero)))\n";
       }
       srcYices += "\n";
       //constaints on 0\leq di < f
       for (int i = 0; i < globalNextOperator.size(); i ++){
           srcYices += "(assert (and (bv-le  d" + i + " f) (bv-ge d" + i + " Zero)))\n";
       }
       srcYices += "\n";
       //constraints on Tmin \leq f \leq Tmax
       if (globalNextOperator.size()>1){
           //srcYices += "(assert (and (bv-le f T"+ (globalNextOperator.size()-1) + ") (bv-ge f T0)))\n";
           srcYices += "(assert (bv-ge f T0))\n";
           srcYices += "(assert (bv-ge (bv-sub T" + (globalNextOperator.size()-1) + " f) Zero))\n";
       }
       return srcYices;
   }
   
}
