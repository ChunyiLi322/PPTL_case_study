import sys
#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: translator.py - class that wraps the whole translation process

from helper import _
from groups import *
from parser import *
from langtools import *
from patterns import *
from ttree import *
from synth import *

# class wrapping the whole translation process
class TemporalTranslator( object ):
    __instance = None
    
    # singleton
    def __new__( cls, *args, **kwargs ):
        if TemporalTranslator.__instance is None:
            return super( TemporalTranslator, cls ).__new__(cls, *args, **kwargs )
        else:
            return TemporalTranslator.__instance


    def __init__( self ): 
        # load parser
        debug( _( 'Loading parser...' ) )
        self.parser = StanfordParser()
        
        # load phrase patterns and synonym groups
        debug( _( 'Loading phrase pattern directory...' ) )
        self.ppd = PhrasePatternDirectory()#patterns.py
        self.gd = GroupDirectory()

        TemporalTranslator.__instance = self
        
    def getleaf(self,tree,leaflist):
        if isinstance(tree,TTTermNode):
            leaflist.append(tree)
            return leaflist
        else:
            nodelist=[]
            nodelist.append(tree.children[0])
            nodelist.append(tree.children[1])
            while(len(nodelist)>0):
                i=nodelist.pop()
                if isinstance(i,TTTermNode):
                    leaflist.append(i)
                else:
                    nodelist.append(i.children[0])
                    nodelist.append(i.children[1])
    def translatepre( self, sentence ,collectlist):
        parse = self.parser.parse( sentence )
        
        # separate the disjunct structures (independent temporal units)
        disjuncter = Disjuncter()
        #ds_structs contain independent etmporal units(depencies) and conjs contain conj 
        ds_structs, conjs = disjuncter.disjunct( parse.get_dependencies() )
       
        # for only one disjunct structure .
        if len(ds_structs)==1:
            for i, ds in enumerate( ds_structs ):
                # extract phrases out of the structure
                sentencesep = SentenceSeparator()
                phrases = sentencesep.separate( ds )

                # order phrases by their position on the original sentence(predicate)
                phrases.sort( lambda a, b: cmp( a.pred.index, b.pred.index ) )
            
                # for each phrase extract tags
                for i, phrase in enumerate( phrases ):
                    tags = self.ppd.tag_this( phrase )#PhrasePatternDirectory
                    phrase.set_tags( tags )
                    
                # synthesize the phrases to the temporal tree
                ttbuilder = TTBuilder()  #ttree.py
                if ttbuilder.build( phrases ):
                    res_formula = ttbuilder.get_tt().get_text(collectlist)

        #process for and or conjection (sentences)
        elif len(ds_structs) >=2:
            #for collecting the builder of ds_structs.
            ttbuilderdict = {}
            for i, ds in enumerate( conjs.keys() ):
                # extract phrases out of the structure
                sentencesep = SentenceSeparator()
                phrases = sentencesep.separate( ds )

                # order phrases by their position on the original sentence(predicate)
                phrases.sort( lambda a, b: cmp( a.pred.index, b.pred.index ) )
            
                # for each phrase extract tags
                for i, phrase in enumerate( phrases ):
                    tags = self.ppd.tag_this( phrase )#PhrasePatternDirectory
                    phrase.set_tags( tags )
            
                
                # synthesize the phrases to the temporal tree
                ttbuilder = TTBuilder()  #ttree.py
                if ttbuilder.build( phrases ):
                    # convert the synthesized temporal tree to LTL formula
                    debug( _( 'TT was successfully built.' ) )
                    ttbuilderdict[ttbuilder]=conjs.get(ds)
                else:
                    debug( _( 'FAILED to build TT' ) )
                    return None
            # all first node of ttbuilder is TTermNode. (bool)      
            allTTermNode = False
            #only one node is not TTermNode.(bool)
            oneNotTTermNode=False
            #count the number of not TTermNode.
            numNotTTermNode = 0
            for ttbuilderTerm in ttbuilderdict.keys():
                if isinstance(ttbuilderTerm.tt[0],TTUntilNode) or isinstance(ttbuilderTerm.tt[0],TTImplNode) or isinstance(ttbuilderTerm.tt[0],TTAfterNode) or isinstance(ttbuilderTerm.tt[0],TTBeforeNode) or isinstance(ttbuilderTerm.tt[0],TTExistenceUntilNode)or isinstance(ttbuilderTerm.tt[0],TTExistenceAfterNode) or isinstance(ttbuilderTerm.tt[0],TTExistenceBeforeNode):
                    numNotTTermNode = numNotTTermNode + 1
                    
            if numNotTTermNode == 1:
                oneNotTTermNode = True
            elif numNotTTermNode == 0:
                allTTermNode = True
            else:
                sys.stderr.write("this king of sentence is not supported by our tool(contain more than one notTTermNode).") 
                sys.exit(1)
            # process the conj containing one notTTermNode.
            if oneNotTTermNode == True:
                ttbuilderconj = TTBuilderConj()#ttree.py
                ttbuilderconj.builder(ttbuilderdict)
            # process the conj containing all TTermNode.
            elif allTTermNode ==True:  # have not process this situation.
                ttbuilderconj_allTTerm = TTBuilderConjAllTTerm()#ttree.py
                ttbuilderconj_allTTerm.builder(ttbuilderdict)
                
            else:
                sys.stderr.write("this king of sentence is not supported by our tool(contain more than one notTTermNode).") 
                sys.exit(1)
                
            for i in ttbuilderdict.keys():  #ttbuilderdict contain one element.  
                #whether contain assume(special processing)
                res_formula = i.get_tt().get_text(collectlist)
                
                if  (isinstance(i.get_tt(),TTImplNode)and not i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTUntilNode) and not i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTAfterNode) and i.get_tt().kwargs.has_key('reverse') ) or (isinstance(i.get_tt(),TTBeforeNode) and not i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceUntilNode) and not i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTExistenceAfterNode) and i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceBeforeNode)and not i.get_tt().kwargs.has_key('reverse')):
                    self.getleaf(i.get_tt().children[0],inputlist)
                    self.getleaf(i.get_tt().children[1],outputlist)
                elif (isinstance(i.get_tt(),TTImplNode)and i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTUntilNode) and i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTAfterNode) and not i.get_tt().kwargs.has_key('reverse') ) or (isinstance(i.get_tt(),TTBeforeNode) and i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceUntilNode) and i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTExistenceAfterNode) and not i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceBeforeNode)and i.get_tt().kwargs.has_key('reverse')):
                    self.getleaf(i.get_tt().children[1],inputlist)
                    self.getleaf(i.get_tt().children[0],outputlist)
                else:
                    self.getleaf(ttbuilder.get_tt(),outputlist)
            
            
            if(len(inputlist)>0):
                for i in inputlist:
                    inputstrlist.append(i.children[0].get_text(collectlist))
                     
            if(len(outputlist)>0):   
                for i in outputlist:
                    outputstrlist.append(i.children[0].get_text(collectlist))
                    
            if(len(inputstrlist)>0):
                input_formula = "INPUT:%s" % ",".join(inputstrlist)
            else:
                input_formula = "INPUT:None" 
                        
            if(len(outputstrlist)>0):
                output_formula = "OUTPUT:%s" % ",".join(outputstrlist)
            else:
                output_formula = "OUTPUT:None" 
            result.append( res_formula )
            result1.append( input_formula )
            result2.append( output_formula )    
            return "; ".join( result ),"; ".join( result1 ),"; ".join( result2 )
                   
    def translate( self, sentence ,collectlist):
        # welcome message ;)
        debug( _( 'Processing "%s"...' ) % sentence )
        
        # parse the sentence
        debug( _( 'Parsing the input...' ) )
        parse = self.parser.parse( sentence )
        
        # separate the disjunct structures (independent temporal units)
        debug( _( 'Separating disjunct structures...' ) )        
        disjuncter = Disjuncter()
        #ds_structs contain independent etmporal units(depencies) and conjs contain conj 
        ds_structs, conjs = disjuncter.disjunct( parse.get_dependencies() )
       
        # for only one disjunct structure .
        if len(ds_structs)==1:
            result = []
            result1 = []
            result2 = []
            last_ds = None
            for i, ds in enumerate( ds_structs ):
                debug( _( 'Extracting menaning of the disjunct structure #%d..' ) % (i+1) )
                # extract phrases out of the structure
                sentencesep = SentenceSeparator()
                phrases = sentencesep.separate( ds )

                # order phrases by their position on the original sentence(predicate)
                phrases.sort( lambda a, b: cmp( a.pred.index, b.pred.index ) )
            
                # for each phrase extract tags
                for i, phrase in enumerate( phrases ):
                    debug( _( 'Processing sentence #%d' ) % ( i + 1 ) )
                    debug( _( 'Deps: %s' ) % str( phrase.deps ) )
                    tags = self.ppd.tag_this( phrase )#PhrasePatternDirectory
                    phrase.set_tags( tags )
                    if len( tags ) > 0:
                        debug( _( '  > Following tags were extracted: %s' % str( ", ".join( [ str( t ) for t in tags ] ) ) ) )
                    else:
                        debug( _( '  > No tags were extracted.' ) )
            
            
                # synthesize the phrases to the temporal tree
                debug( _( 'Running synthesizers.' ) )
                ttbuilder = TTBuilder()  #ttree.py
                if ttbuilder.build( phrases ):
                    # convert the synthesized temporal tree to LTL formula
                    debug( _( 'TT was successfully built.' ) )
                    #whether contain Assume(special processing).
                    containAssume = False
                    for i in ttbuilder.get_tt().get_temporal_operators_recursive():
                        if i.name == 'assume':
                            containAssume = True
                            
                    if containAssume:
                        res_formula = "ASSUME"+ttbuilder.get_tt().get_text(collectlist)
                    else:
                        res_formula = ttbuilder.get_tt().get_text(collectlist)

                   
                    # added by CYS in 2013.9.5.
                    inputlist = []
                    outputlist = []
                    inputstrlist=[]
                    outputstrlist=[]
                    if  (isinstance(ttbuilder.get_tt(),TTImplNode)and not ttbuilder.get_tt().kwargs.has_key('reverse'))or (isinstance(ttbuilder.get_tt(),TTUntilNode) and not ttbuilder.get_tt().kwargs.has_key('reverse'))or (isinstance(ttbuilder.get_tt(),TTAfterNode) and ttbuilder.get_tt().kwargs.has_key('reverse') ) or (isinstance(ttbuilder.get_tt(),TTBeforeNode) and not ttbuilder.get_tt().kwargs.has_key('reverse')) or (isinstance(ttbuilder.get_tt(),TTExistenceUntilNode) and not ttbuilder.get_tt().kwargs.has_key('reverse'))or (isinstance(ttbuilder.get_tt(),TTExistenceAfterNode) and ttbuilder.get_tt().kwargs.has_key('reverse')) or (isinstance(ttbuilder.get_tt(),TTExistenceBeforeNode)and not ttbuilder.get_tt().kwargs.has_key('reverse')):
                        self.getleaf(ttbuilder.get_tt().children[0],inputlist)
                        self.getleaf(ttbuilder.get_tt().children[1],outputlist)
                    elif (isinstance(ttbuilder.get_tt(),TTImplNode)and ttbuilder.get_tt().kwargs.has_key('reverse'))or (isinstance(ttbuilder.get_tt(),TTUntilNode) and ttbuilder.get_tt().kwargs.has_key('reverse'))or (isinstance(ttbuilder.get_tt(),TTAfterNode) and not ttbuilder.get_tt().kwargs.has_key('reverse') ) or (isinstance(ttbuilder.get_tt(),TTBeforeNode) and ttbuilder.get_tt().kwargs.has_key('reverse')) or (isinstance(ttbuilder.get_tt(),TTExistenceUntilNode) and ttbuilder.get_tt().kwargs.has_key('reverse'))or (isinstance(ttbuilder.get_tt(),TTExistenceAfterNode) and not ttbuilder.get_tt().kwargs.has_key('reverse')) or (isinstance(ttbuilder.get_tt(),TTExistenceBeforeNode)and ttbuilder.get_tt().kwargs.has_key('reverse')):
                        self.getleaf(ttbuilder.get_tt().children[1],inputlist)
                        self.getleaf(ttbuilder.get_tt().children[0],outputlist)
                    else:
                        self.getleaf(ttbuilder.get_tt(),outputlist)
                    
                    if(len(inputlist)>0):
                        for i in inputlist:
                            inputstrlist.append(i.children[0].get_text(collectlist))
                     
                    if(len(outputlist)>0):   
                        for i in outputlist:
                            outputstrlist.append(i.children[0].get_text(collectlist))
                    if(len(inputstrlist)>0):
                        input_formula = "INPUT:%s" % ",".join(inputstrlist)
                    else:
                        input_formula = "INPUT:None" 
                        
                    if(len(outputstrlist)>0):
                        output_formula = "OUTPUT:%s" % ",".join(outputstrlist)
                    else:
                        output_formula = "OUTPUT:None" 
                    result.append( res_formula )
                    result1.append( input_formula )
                    result2.append( output_formula )
                else:
                    debug( _( 'FAILED to build TT' ) )
                    return None


                last_ds = ds
            return "; ".join( result ),"; ".join( result1 ),"; ".join( result2 )
        #process for and or conjection (sentences)
        elif len(ds_structs) >=2:
            result = []
            result1 = []
            result2 = []
            #for collecting the builder of ds_structs.
            ttbuilderdict = {}
            for i, ds in enumerate( conjs.keys() ):
                debug( _( 'Extracting menaning of the disjunct structure #%d..' ) % (i+1) )
                # extract phrases out of the structure
                sentencesep = SentenceSeparator()
                phrases = sentencesep.separate( ds )

                # order phrases by their position on the original sentence(predicate)
                phrases.sort( lambda a, b: cmp( a.pred.index, b.pred.index ) )
            
                # for each phrase extract tags
                for i, phrase in enumerate( phrases ):
                    tags = self.ppd.tag_this( phrase )#PhrasePatternDirectory
                    phrase.set_tags( tags )
            
                
                # synthesize the phrases to the temporal tree
                ttbuilder = TTBuilder()  #ttree.py
                if ttbuilder.build( phrases ):
                    # convert the synthesized temporal tree to LTL formula
                    debug( _( 'TT was successfully built.' ) )
                    ttbuilderdict[ttbuilder]=conjs.get(ds)
                else:
                    debug( _( 'FAILED to build TT' ) )
                    return None
            # all first node of ttbuilder is TTermNode. (bool)      
            allTTermNode = False
            #only one node is not TTermNode.(bool)
            oneNotTTermNode=False
            #count the number of not TTermNode.
            numNotTTermNode = 0
            for ttbuilderTerm in ttbuilderdict.keys():
                if isinstance(ttbuilderTerm.tt[0],TTUntilNode) or isinstance(ttbuilderTerm.tt[0],TTImplNode) or isinstance(ttbuilderTerm.tt[0],TTAfterNode) or isinstance(ttbuilderTerm.tt[0],TTBeforeNode) or isinstance(ttbuilderTerm.tt[0],TTExistenceUntilNode)or isinstance(ttbuilderTerm.tt[0],TTExistenceAfterNode) or isinstance(ttbuilderTerm.tt[0],TTExistenceBeforeNode):
                    numNotTTermNode = numNotTTermNode + 1
                    
            if numNotTTermNode == 1:
                oneNotTTermNode = True
            elif numNotTTermNode == 0:
                allTTermNode = True
            else:
                sys.stderr.write("this king of sentence is not supported by our tool(contain more than one notTTermNode).") 
                sys.exit(1)
            # process the conj containing one notTTermNode.
            if oneNotTTermNode == True:
                ttbuilderconj = TTBuilderConj()#ttree.py
                ttbuilderconj.builder(ttbuilderdict)
            # process the conj containing all TTermNode.
            elif allTTermNode ==True:  # have not process this situation.
                ttbuilderconj_allTTerm = TTBuilderConjAllTTerm()#ttree.py
                ttbuilderconj_allTTerm.builder(ttbuilderdict)
                
            else:
                sys.stderr.write("this king of sentence is not supported by our tool(contain more than one notTTermNode).") 
                sys.exit(1)
            inputlist = []
            outputlist = []
            inputstrlist=[]
            outputstrlist=[]
            for i in ttbuilderdict.keys():  #ttbuilderdict contain one element.  
                #whether contain assume(special processing)
                containAssume = False
                for j in i.get_tt().get_temporal_operators_recursive():
                        if j.name == 'assume':
                            containAssume = True
                            
                if containAssume:
                    res_formula = "Assume"+i.get_tt().get_text(collectlist)
                else:
                    res_formula = i.get_tt().get_text(collectlist)
                
                if  (isinstance(i.get_tt(),TTImplNode)and not i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTUntilNode) and not i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTAfterNode) and i.get_tt().kwargs.has_key('reverse') ) or (isinstance(i.get_tt(),TTBeforeNode) and not i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceUntilNode) and not i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTExistenceAfterNode) and i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceBeforeNode)and not i.get_tt().kwargs.has_key('reverse')):
                    self.getleaf(i.get_tt().children[0],inputlist)
                    self.getleaf(i.get_tt().children[1],outputlist)
                elif (isinstance(i.get_tt(),TTImplNode)and i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTUntilNode) and i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTAfterNode) and not i.get_tt().kwargs.has_key('reverse') ) or (isinstance(i.get_tt(),TTBeforeNode) and i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceUntilNode) and i.get_tt().kwargs.has_key('reverse'))or (isinstance(i.get_tt(),TTExistenceAfterNode) and not i.get_tt().kwargs.has_key('reverse')) or (isinstance(i.get_tt(),TTExistenceBeforeNode)and i.get_tt().kwargs.has_key('reverse')):
                    self.getleaf(i.get_tt().children[1],inputlist)
                    self.getleaf(i.get_tt().children[0],outputlist)
                else:
                    self.getleaf(ttbuilder.get_tt(),outputlist)
            
            
            if(len(inputlist)>0):
                for i in inputlist:
                    inputstrlist.append(i.children[0].get_text(collectlist))
                     
            if(len(outputlist)>0):   
                for i in outputlist:
                    outputstrlist.append(i.children[0].get_text(collectlist))
                    
            if(len(inputstrlist)>0):
                input_formula = "INPUT:%s" % ",".join(inputstrlist)
            else:
                input_formula = "INPUT:None" 
                        
            if(len(outputstrlist)>0):
                output_formula = "OUTPUT:%s" % ",".join(outputstrlist)
            else:
                output_formula = "OUTPUT:None" 
            result.append( res_formula )
            result1.append( input_formula )
            result2.append( output_formula )    
            return "; ".join( result ),"; ".join( result1 ),"; ".join( result2 )
            
                
                    
        
class CollectSubPre:
    subject=""
    predicate=[]
    antonymPairList =[]
    def _init_(self):
        self.subject=""
        self.predicate=[]
        self.antonymPairList=[]
    
class CollectSubPreList:
    collectsubprelist = []
    def _init_(self):
        self.collectsubprelist = []
    def search(self,subjectword):
        res = False
        if len(self.collectsubprelist)>0:
            for i in self.collectsubprelist:
                if i.subject.lower()==subjectword.lower():
                    res = True
        return res
    
class Antonym:
    wordList=[]
    oppositeWordList=[]
    def _init_(self):
        self.wordList=[]
        self.oppositeWordList=[]
        
class AntonymList:
    antonymList=[]
    def _init_(self):
        self.antonymList=[]
        
    def find_antonymlist(self,predicate):
        """"""
        res=[]
        for i in self.antonymList:
            if predicate in i.wordList:
                res.extend(i.oppositeWordList)
            elif predicate in i.oppositeWordList:
                res.extend(i.wordList)
        return res
        
        
class PredicateTerm:
    predicate=""
    #get antonyms from antonymDict.txt
    antonymDict=[]
    #get antonyms from File.
    antonymFile=[]
    flag = 0
    color=""
    def _init_(self):
        self.predicate=""
        self.antonymDict=[]
        self.antonymFile=[]
        self.flag = 0
        self.color=""
        
class PredicateTermList:
    predicateTermList=[]
    def _init_(self):
        self.predicateTermList=[]
    #whether the element in termList all hava falg value that is not 0.   
   
        

class AssignFlag:
    """The depth of the search assignment and assign flag value,for PredicateTermList."""
    def assignflag(self,cPredicateTermList,antonymList,flag):
        if self.allassignflag(cPredicateTermList,antonymList):
            return None
        else:
            flag=-flag
            for i in antonymList:
                for j in cPredicateTermList.predicateTermList:
                    if i==j.predicate and j.flag==0:
                        j.flag=flag
                        self.assignflag(cPredicateTermList,j.antonymFile,j.flag)
    #justify the value of all termList element is not 0.
    def allassignflag(self,cPredicateTermList,termList):
        res=True
        for i in termList:
            for j in cPredicateTermList.predicateTermList:
                if j.predicate==i and j.flag==0:
                    res=False
                    break
        return res
    
class DealCollectSubPre:
    """process the antonymPairList of CollectSubPre."""
    
                            
                
class ElementForCsubpre:
    """for antonymPairList in CollectSubPre."""
    possitivePredicate = []
    negativePredicate = []
    def _init_(self):
        self.possitivePredicate = []
        self.negativePredicate = []
