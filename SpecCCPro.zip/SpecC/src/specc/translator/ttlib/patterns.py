#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: patterns.py - methods and classes for pattern matching and tag extraction

from groups import *
from parser import *
import yaml
#
# Patterns
#
class Tag:
    """Holds information about a tag."""

    # tag name
    name = None

    # tag arguments (None, or a list)
    args = None

    def __init__( self, name = None, args = None ):
        self.name = name
        self.args = args

    def __repr__( self ):
        return "<Tag: %s %s>" % ( self.name, str( self.args ) )


class Pattern:
    """Pattern used for matching against typed dependencies from a phrase."""
    # class of this phrase (or a set of classes) = tag(s)
    cls = None

    # dependencies that have to be present in a phrase in order for this pattern 
    # to match and assign the tags
    dependency_list = None


    def __init__( self ): self.dependency_list = []

    def match( self, phrase ):
        """Try to match the given phrase @phrase against this pattern. Return a set of
        extracted tags."""

        # dependencies to match
        tdl = phrase.deps#list
        res = True
        total_match = []
        
        # match each required dependency with the typed dependecies list @tdl
        context = {}
        for dep in self.dependency_list:
            was_there = False
            for td in tdl:
                match = dep.match( td, phrase, context )
                
                # if we find a match, we just propagate it up and don't need to continue
                if match is not None:
                    total_match += [ match ]
                    was_there = True

                    break
            
            # if we didn't find a match, it's a fail -> return false
            if not was_there:
                res = False
                break
        
        # if all dependencies matched somehow
        if res is True:
            # if our cls (tags) is a list, create a tag for each, and populate it with
            # the extracted arguments
            if type( self.cls ) is list:
                res = []
                for cls in self.cls:
                    r = Tag()
                    r.name = cls
                    r.args = []
                    for m in total_match:
                        r.args += m.tag_args()

                    res.append( r )
                return res
            # or, create a single tag and populate it with the extracted arguments
            else:
                r = Tag()
                r.name = self.cls
                r.args = []
                for m in total_match:
                    r.args += m.tag_args()
                return r
        else:
            # if the pattern doesn't match the phrase, return None
            return None

#
# value matching patterns
#
class PValue:
    """The tested word must be exactly of the value of this class."""
    value = None
    def match( self, tested_word, phrase, context = {} ):
        return self.compare( self.value, WordStemmer().stemstr( tested_word ) )

    def compare( self, val1, val2 ):
        #modified by CYS in 2013.9.22 for the "is true" in sentence.(line:109-114) 
        if val1 =="t rue":
            return "true" == val2.lower()
        elif val1=="f alse":
            return "false"== val2.lower()    
        else:
            return val1.lower() == val2.lower() #cmp( val1, val2 ) == 0

class PValueList( PValue ):
    """The tested word must be exactly of one of the values of this class."""
    value = None
    def match( self, tested_word, phrase, context = {} ):
        for i in self.value:
            if self.compare( i, WordStemmer().stemstr( tested_word ) ):
                return True
        return False


class PTagArg( PValue ):
    """The tested word is taken and returned to result as an argument."""
    def match( self, tested_word, phrase, context = {} ):
        return tested_word

class PPredicate( PValue ):
    """The tested word must be the predicate of the phrase."""
    group = value = None
    def match( self, tested_word, phrase, context = {} ):
        pred = WordStemmer().stem( phrase.get_pred() )
        # first step, check if it is a predicate
        res = WordStemmer().stem( tested_word ) == pred

        # second step, check if a group require or value to check against is set
        if self.group is not None:
            res = res and ( GroupDirectory().in_group( pred.value, self.group ) )
        elif self.value is not None:
            res = res and pred.value.lower() == self.value.lower()
        
        return res

class PSubject( PValue ):
    def match( self, tested_word, phrase, context = {} ):
        """The tested word must be the subject of the phrase."""
        return phrase.in_subjs( WordStemmer().stem( tested_word.value ) )

class PGroup( PValue ):
    """The tested word must exactly match one of the values in the given synonym
    group of words."""
    def match( self, tested_word, phrase, context = {} ):
        return GroupDirectory().in_group( WordStemmer().stem( tested_word ).value, self.name )

class PVariable( PValue ):
    """When the tested word is checked for a particular pattern first, it is saved and 
    the matching function returns true, and the second time, the word is checked against
    the saved value."""
    name = None
    def match( self, tested_word, phrase, context = {} ):
        stemmed = WordStemmer().stemstr( tested_word )
        if context.has_key( self.name ):
            if self.compare( context[ self.name ], stemmed ):
                return True
            else:
                return False
        else:
            context[ self.name ] = stemmed
            return True

        return GroupDirectory().in_group( WordStemmer().stem( tested_word ).value, self.name )

class PatternDependencyMatch:
    """Holds result of matching a pattern with a particular typed dependency."""
    reln = None
    gov = None
    dep = None

    FALSE_VALS = [ False ]

    def is_match( self ):
        if self.reln is not None:
            if ( self.reln in self.FALSE_VALS ):
                return False        
        if self.gov is not None:
            if ( self.gov in self.FALSE_VALS ):
                return False
        if self.dep is not None:
            if ( self.dep in self.FALSE_VALS ):
                return False
        return True
    
    
    def tag_args( self ):
        """Get tags for this match (= return each non-bool value)."""
        res = []
        if self.reln is not None and type( self.reln ) is not bool: res.append( self.reln )
        if self.gov is not None and type( self.gov ) is not bool: res.append( self.gov )
        if self.dep is not None and type( self.dep ) is not bool: res.append( self.dep )

        return res


class PatternDependency:
    """Works as a pattern for a typed dependency and facilitates its matching and
    required information extraction."""
    reln = None
    gov = None
    dep = None
    
    def match( self, td, phrase, context = {} ):
        """Matches this typed dependency?"""
        res = PatternDependencyMatch()

        # match name
        if self.reln is not None:
            if type( self.reln.value ) is list:
                res.reln = False
                for i in self.reln.value:
                    res.reln = res.reln or td.in_relns( i )
            else:
                res.reln = td.in_relns( self.reln.value )

        # match gov
        if self.gov is not None:
            res.gov = self.gov.match( td.gov, phrase, context )

        # match dep
        if self.dep is not None:
            res.dep = self.dep.match( td.dep, phrase, context )
        
        # if the match was successfull, return it, otherwise None
        if res.is_match():
            return res
        else:
            return None

class PhrasePatternDirectory:
    """Facilitates pattern loading from a yaml file."""
    def __init__( self, file = "src/specc/translator/phrasepatterns.yaml" ):
        # import serialized patterns
        self.load_yaml( file )

    def load_yaml( self, file ):
        """Load patterns from @file file."""
        try:
            f = open( file, 'rb' )
            ys = yaml.load( f.read() )
        except IOError:
            err( _( 'Error saving file "%s" with patterns' ) % file )

        # for each pattern in the file, create corresponding instances and fill them
        # with information
        self.ppdir = []#the list of the object of Pattern 
        for p in ys:  #transform phrasepattern.yaml into np(Pattern).
            np = Pattern()
            self.ppdir.append( np )
            np.cls = p[ 'cls' ]
            for d in p[ 'dependency_list' ]:#d is a map which contain reln,or gov or dep.
                nd = PatternDependency()

                for x in [ 'reln', 'gov', 'dep' ]:
                    if not d.has_key( x ):
                        continue
                    
                    if d[ x ][ 'type' ] == 'value':
                        val = d[ x ][ 'value' ]
                        if type( val ) is list:
                            v = PValueList()
                        else:
                            v = PValue()
                        v.value = val
                        setattr( nd, x, v )
                    elif d[ x ][ 'type' ] == 'tagarg':
                        v = PTagArg()
                        v.number = d[ x ][ 'number' ]
                        setattr( nd, x,  v )
                    elif d[ x ][ 'type' ] == 'predicate':
                        v = PPredicate()
                        v.group = d[ x ].get( 'group' )
                        v.value = d[ x ].get( 'value' )
                        setattr( nd, x, v )
                    elif d[ x ][ 'type' ] == 'subject':
                        v = PSubject()
                        setattr( nd, x, v )
                    elif d[ x ][ 'type' ] == 'group':
                        v = PGroup()
                        v.name = d[ x ][ 'name' ]
                        setattr( nd, x, v )
                    elif d[ x ][ 'type' ] == 'variable':
                        v = PVariable()
                        v.name = d[ x ][ 'name' ]
                        setattr( nd, x, v )

                np.dependency_list.append( nd )




    def tag_this( self, phrase ):
        """Goes through patterns and tries to match them with the typed dependencies. Returns a list of tags."""
        res = []
        for patt in self.ppdir:#patt is the object of Pattern.
            pm = patt.match( phrase )#match phrase with the typed dependencies.(class PatternDependency)
            if pm is not None:
                if type( pm ) is list:
                    res += pm
                else:
                    res.append( pm )

        return res

        pass

    def add( self, pattern ):
        """Adds new phrase."""
        self.ppdir.append( pattern )
        
    def haspredicate(self,predicate):
        res = False
        for i in self.ppdir:
            for j in i.dependency_list:
                #whether gov contain predicate
                if isinstance(j.gov,PValue):
                    if j.gov.value == predicate:
                        res = True
                elif isinstance(j.gov,PValueList):
                    if predicate in j.gov.value:
                        res = True
                #whether dep contain precicate.       
                if isinstance(j.dep,PValue):
                    if j.dep.value == predicate:
                        res = True
                elif isinstance(j.dep,PValueList):
                    if predicate in j.dep.value:
                        res = True
        return res
