#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: parser.py - methods and classes for parsing natural language

import jpype
import sys
import warnings

from ttlib import *

class Parser: 
    """ do nothing."""
    pass

class Parse:
    """Holds results of a particular parse."""
    def get_dependencies():
        pass

class StanfordParse( Parse ):
    """Holds parser output of The Stanford Parser."""
    def __init__( self, tdl ):
        self.tdl = tdl
        self.deps = self.build_deps( tdl )
    
    def get_dependencies( self ):
        return self.deps

    def build_deps( self, tdl ):
        """Populate self with dependencies from stanford @tdl."""
        res = TypedDependencies()
        for td in tdl:
            if not td.reln().shortName=="root":
                d = TypedDependency()
                d.relns = []
                top_act = act = td.reln()
            
                d.reln_specific=act.specific
                #print d.reln_specific
                while act is not None:
                    d.relns.append( act.shortName )
                    act = act.parent
                d.relns.append( "%s_%s" % ( top_act.shortName, d.reln_specific, ) )
                d.gov = Word( td.gov().value(), td.gov().index(), td.gov().parent().value() )#td.gov().value()?
                d.dep = Word( td.dep().value(), td.dep().index(), td.dep().parent().value () )
                #print d #delete
                res.deps.append( d )
          
        #print res.deps #delete
        return res

class StanfordParser( Parser ):
    """Implementation of parser interface to The Stanford Parser."""
    def __init__( self ):
        
        # do the imports
        lexparser = jpype.JPackage("edu.stanford.nlp.parser.lexparser")
        self._trees = jpype.JPackage("edu.stanford.nlp.trees")
        
        # suppress messages that the parser would print out
        ous = OutSuppresser( sys.stderr )
        ous.suppress()
        
        # load and construct parser, and parse our sentence
        LexicalizedParser = lexparser.LexicalizedParser
        self.lp = LexicalizedParser.loadModelFromZip( "src/specc/translator/englishPCFG.zip","englishPCFG.ser" ) 
        ous.revert()

    def parse( self, sentence ):
        """Parse the given sentence and return the corresponding Parse object."""
        parse = self.lp.apply( sentence )

        tlp = self._trees.PennTreebankLanguagePack();
        gsf = tlp.grammaticalStructureFactory();
        gs = gsf.newGrammaticalStructure(parse);
        tdl = gs.typedDependenciesCollapsed();
        #print tdl    #delete
        res = StanfordParse( tdl )
        return res

class WordStemmer:
    def __init__( self ):
        self._process = jpype.JPackage("edu.stanford.nlp.process")

    def stem( self, word ):
        """Get stem of @word."""
        ws = self._process.Morphology()
        stem = ws.stem(word.value)
        nw = Word( stem, word.index, word.type )
        return nw

    def stemstr( self, word ):
        return self.stem( word ).value

class Word:
    """Holds information of a word."""

    # the text
    value = None

    # the index in the sentence
    index = None

    def __init__( self, value, index = -1, type = None ):
        self.value = value.lower()
        self.index = index
        self.type = type

    def __repr__( self ):
        return "<Word: %s-%d>" % ( self.value, self.index, )

    def __eq__( self, other ):
        # when comparing two words its enough to compare indexes as 2 words in one sentence
        # will never have the same index.
        if isinstance( other, Word ):
            if self.index != -1 and other.index != -1:
                return self.index == other.index
            else:
                return self.value == other.value
        else:
            return False

    def __cmp__( self, other ):
        return cmp( self.index, other.index )

    def __hash__( self ):
        return self.index

    @classmethod
    def match( self, w1, w2 ):
        return w1.value.lower() == w2.value.lower()


class Dependency:
    """Generic class representing gramatical dependency. E.g.: subj(assert, signal)"""
    # relationship name
    def reln():
        def fget( self ):
            return self.relns[ 0 ]
        return locals()
    reln = property( **reln() )
    
    # last relationship name in the tree of relationship types
    def reln_last():
        def fget( self ):
            return self.relns[ -1 ]
        return locals()
    reln_last = property( **reln_last() )

    def in_relns( self, what ):
        if what in self.relns:
            return True
        else:
            return False

    relns = None # list of relation names (chronologically from current to ancestors)
    gov = None # dependency head (governor)
    dep = None # dependency tail (dependant)


#
# Typed dependencies
#
class TypedDependency( Dependency ):
    def __repr__( self ):
        return "<TD: %s(%s, %s)>" % ( self.reln, self.gov, self.dep, )

class TypedDependencies:
    """Holds a set of typed dependencies (result of a parse)."""
    deps = None

    def __init__( self ):
        self.deps = []

    def __iter__( self ):
        for i in self.deps:
            yield i
    
    def __getitem__( self, item ):
        return self.deps[ item ]  
    
    def __len__( self ):
        return len( self.deps )

    def remove( self, x ):
        self.deps.remove( x )
