#!/usr/bin/python
# project: Temporal Logic For Men
# program: Temporal Translator
# description: Translates a sentence from English to LTL (temporal logic).
# author: Lukas Zilka
# date: March 2010
# file: synth.py - methods and classes for synthesizing list of phrases into temporal tree

from patterns import *
from ttree import *

class Synthesizer:
    """Abstrat class for Synthesizers. Contains common functionality."""
    def check_pre( self, plist ):
        """Custom synthsizer will override this in order to check its input
        phrases."""
        return True
    
    def find_pre( self, plist ):
        """Find the position of first suitable phrase pair that render check_pre true."""
        for i in range( len( plist ) - 1 ):
            if self.check_pre( plist[ i:i+2 ] ):
                return i

    def synth( self, plist ):
        """Execute the code for synthesizing. Usually a reduction code's going to
        be performed."""
        pos = self.find_pre( plist )
        if not pos is None:
            self.do_synth( plist, pos )
            return True
        return False

class AdjSynth( Synthesizer ):
    """Abstract class. Adjacent synthesizer. Synthesizer that checks if the first sentence has
    @tags1 and the second one has @tags2 and the first one doesn't have @tags1_not 
    and the second one doesn't have @tags2_not. If the check is successfull it proceeds
    with reduction and replaces the two matching phrases with the new one which is
    an instance of @node_class."""
    tags1 = []
    tags1_not = []
    tags2 = []
    tags2_not = []
    node_class = None
    node_class_kwargs = {}

    def check_pre( self, plist ):
        # if there's not enough phrases to synth we must fail
        if len( plist ) < 2:
            return False

        # check for desired tags
        if not plist[0].has_tag( *self.tags1 ):
            return False
        if not plist[1].has_tag( *self.tags2 ):
            return False
        
        # check for undesired tags
        for t in self.tags1_not:
            if plist[0].has_tag( t ):
                return False
        
        for t in self.tags2_not:
            if plist[1].has_tag( t ):
                return False

        return True

    def do_synth( self, plist, pos ):
        # takes the first 2 matching phrases and replaces them with one and builds
        # the temporal tree this way
        newnode = self.node_class( self.node_class_kwargs )
        newnode.add_child( plist[pos], plist[ pos + 1 ] )
        del plist[ pos ]
        del plist[ pos ]
        plist.insert( pos, newnode )


# list of possible class of phrases
ALL_TAGS = [Tag( 'if' ), Tag( 'until' ), Tag( 'after' ), Tag( 'before' )]
ALL_TAGS_EXISTENCE = [Tag( 'if' ), Tag( 'until' ), Tag( 'after' ),Tag( 'before' ),Tag('existence')]
# if something, something2: something -> something2
class ImplSynth( AdjSynth ):
    tags1 = [ Tag( 'if' ) ]
    tags1_not = [ ]
    tags2 = [ ]
    tags2_not = ALL_TAGS
    node_class = TTImplNode


# something, if something2: something2 -> something
class RevImplSynth( AdjSynth ):
    tags1 = [ ]
    tags1_not = ALL_TAGS
    tags2 = [ Tag( 'if' ) ]
    tags2_not = [ ]
    node_class = TTImplNode
    node_class_kwargs = { 'reverse': True }

# until something, something2: something2 U something
class UntilSynth( AdjSynth ):
    tags1 = [ Tag( 'until' ) ]
    tags1_not = [ ]
    tags2 = [ ]
    tags2_not = ALL_TAGS_EXISTENCE
    node_class = TTUntilNode
    node_class_kwargs = { 'reverse': True }

# something, until something2: something U something2
class RevUntilSynth( AdjSynth ):
    tags1 = [ ]
    tags1_not = ALL_TAGS_EXISTENCE
    tags2 = [ Tag( 'until' ) ]
    tags2_not = [ ]
    node_class = TTUntilNode

# after something, something2: F(something -> {X,F}something2)
class AfterSynth( AdjSynth ):
    tags1 = [ Tag( 'after' ) ]
    tags1_not = [ ]
    tags2 = [ ]
    tags2_not = ALL_TAGS_EXISTENCE
    node_class = TTAfterNode
    node_class_kwargs = { 'reverse': True }
    
    """def do_synth( self, plist, pos ):
        # Y after X
        # X => ( Y U !X )

        impl = TTImplNode()
        impl.add_tag( Tag( 'future' ) )

        impl.add_child( plist[ pos  ], plist[ pos + 1 ] )
        
        newnode = impl
        del plist[ pos ]
        del plist[ pos ]
        plist.insert( pos, newnode )"""

# something, after something2: F(something2 -> {X,F}something2)
class RevAfterSynth( AdjSynth ):
    tags1 = [ ]
    tags1_not = ALL_TAGS_EXISTENCE
    tags2 = [ Tag( 'after' ) ]
    tags2_not = [ ]
    node_class = TTAfterNode
    """def do_synth( self, plist, pos ):
        # Y after X
        # X => ( Y U !X )

        impl = TTImplNode()
        impl.add_tag( Tag( 'future' ) )

        impl.add_child( plist[ pos + 1 ], plist[ pos ] )
        
        newnode = impl
        del plist[ pos ]
        del plist[ pos ]
        plist.insert( pos, newnode )"""
        
# Before something1, something2
class BeforeSynth( AdjSynth ):
    tags1 = [ Tag( 'before' ) ]
    tags1_not = [ ]
    tags2 = [ ]
    tags2_not = ALL_TAGS_EXISTENCE
    node_class = TTBeforeNode
    node_class_kwargs = { 'reverse': True }
    
# something1, before something2
class RevBeforeSynth( AdjSynth ):
    tags1 = [ ]
    tags1_not = ALL_TAGS_EXISTENCE
    tags2 = [ Tag( 'before' ) ]
    tags2_not = [ ]
    node_class = TTBeforeNode


# until something, something2: something2 U something
class ExistenceUntilSynth( AdjSynth ):
    tags1 = [ Tag( 'until' ) ]
    tags1_not = [ ]
    tags2 = [Tag('existence') ]
    tags2_not = ALL_TAGS
    node_class = TTExistenceUntilNode
    node_class_kwargs = { 'reverse': True }

# something, until something2: something U something2
class RevExistenceUntilSynth( AdjSynth ):
    tags1 = [Tag('existence') ]
    tags1_not = ALL_TAGS
    tags2 = [ Tag( 'until' ) ]
    tags2_not = [ ]
    node_class = TTExistenceUntilNode

# after something, something2: F(something -> {X,F}something2)
class ExistenceAfterSynth( AdjSynth ):
    tags1 = [ Tag( 'after' ) ]
    tags1_not = [ ]
    tags2 = [ Tag('existence') ]
    tags2_not = ALL_TAGS
    node_class = TTExistenceAfterNode
    node_class_kwargs = { 'reverse': True }
    
    
# something, after something2: F(something2 -> {X,F}something2)
class RevExistenceAfterSynth( AdjSynth ):
    tags1 = [Tag('existence') ]
    tags1_not = ALL_TAGS
    tags2 = [ Tag( 'after' ) ]
    tags2_not = [ ]
    node_class = TTExistenceAfterNode
    
# Before something1, something2
class ExistenceBeforeSynth( AdjSynth ):
    tags1 = [ Tag( 'before' ) ]
    tags1_not = [ ]
    tags2 = [ Tag('existence')]
    tags2_not = ALL_TAGS
    node_class = TTExistenceBeforeNode
    node_class_kwargs = { 'reverse': True }
    
# something1, before something2
class RevExistenceBeforeSynth( AdjSynth ):
    tags1 = [Tag('existence') ]
    tags1_not = ALL_TAGS
    tags2 = [ Tag( 'before' ) ]
    tags2_not = [ ]
    node_class = TTExistenceBeforeNode
  
# list of all synthesizers to be considered at the time of synthesis
__SYNTHESIZERS__ = [ RevImplSynth, RevUntilSynth, RevAfterSynth, RevBeforeSynth, RevExistenceUntilSynth, RevExistenceAfterSynth, RevExistenceBeforeSynth,ImplSynth, UntilSynth, AfterSynth ,BeforeSynth, ExistenceUntilSynth, ExistenceAfterSynth ,ExistenceBeforeSynth]
