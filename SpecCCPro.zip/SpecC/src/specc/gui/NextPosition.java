/* SPecCC: Specification Consistency Checking
 *
 * Copyright (c) 2014, Rongjie Yan, 
 * All rights reserved.
    
 * This file is part of SpecCC.

 * SpecCC is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 *  SpecCC is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with SpecCC.  If not, see <http://www.gnu.org/licenses/>.
 */
package specc.gui;

import java.io.Serializable;

/**
 *
 * @author yrj
 */
@SuppressWarnings("serial")
public class NextPosition implements Serializable {
    public int pos=-1;
    public int length=0;
    public int index=-1;
    
    public NextPosition(){
    
    }
    public void setPos(int newPos){
        pos = newPos;
    }
    
    public int getPos(){
        return pos;
    }
    
    public void setLength(int newLength){
        pos = newLength;
    }
    
    public int getLength(){
        return length;
    }
    
}
